"""Inference-path post-processing and the boundary-confidence scalar.

Section 3.6 of the manuscript separates the two computational graphs, and the
separation is enforced here rather than left to a comment:

* :func:`inference_mask` is the **inference path**. Otsu thresholding,
  binarisation, closing, opening, hole filling and connected-component
  selection are non-differentiable, they run under NumPy/scikit-image, and
  nothing in this function is ever called inside a gradient tape. It produces
  every number reported in Section 4.
* :func:`soft_confidence` is the **training path**. During joint fine-tuning
  the classifier consumes the unthresholded region map R_hat together with
  c_soft = sum(E_hat * E_hat) / sum(E_hat), a contour-free surrogate that is a
  smooth function of Theta_seg, so dL_class/dTheta_seg is well defined.

Ablation variant (F) removes the morphology: pass ``use_morphology=False``.
"""
from __future__ import annotations

import numpy as np
import tensorflow as tf
from scipy import ndimage
from skimage.filters import threshold_otsu
from skimage.measure import label
from skimage.morphology import disk

try:                                  # scikit-image >= 0.26
    from skimage.morphology import closing as _closing, opening as _opening
except ImportError:                   # pragma: no cover - older releases
    from skimage.morphology import (binary_closing as _closing,
                                    binary_opening as _opening)

from .config import MORPH_DISK_RADIUS, OTSU_BINS, CONNECTIVITY

_EPS = 1e-8


def otsu_threshold(region_map: np.ndarray, bins: int = OTSU_BINS) -> float:
    """Per-image Otsu threshold on R_hat, 256-bin histogram (Section 3.12)."""
    r = np.asarray(region_map, np.float64).ravel()
    lo, hi = r.min(), r.max()
    if hi - lo < 1e-12:
        return float(lo)
    return float(threshold_otsu(r, nbins=bins))


def inference_mask(region_map: np.ndarray,
                   use_morphology: bool = True,
                   radius: int = MORPH_DISK_RADIUS) -> np.ndarray:
    """M*_lesion: threshold R_hat, close, open, fill holes, keep largest component.

    Mirrors lines 42-48 of Algorithm 1(b). Equations (16)-(18) of Section 3.7
    act on this binarised region map M_bin = [R_hat > tau], not on the
    boundary map.
    """
    r = np.asarray(region_map, np.float32)
    if r.ndim == 3:
        r = r[..., 0]
    tau = otsu_threshold(r)
    m = r > tau                                   # M_bin, Eq. (18) input
    if use_morphology:
        se = disk(radius)
        m = _closing(m, se)                       # Eq. (16) then Eq. (17)
        m = _opening(m, se)
        m = ndimage.binary_fill_holes(m)
    if m.any():
        structure = np.ones((3, 3), int) if CONNECTIVITY == 8 else None
        lab = label(m, connectivity=2 if CONNECTIVITY == 8 else 1)
        sizes = np.bincount(lab.ravel())
        sizes[0] = 0
        m = lab == int(sizes.argmax())            # largest connected component
    return m.astype(np.float32)


def mask_contour(mask: np.ndarray) -> np.ndarray:
    """dM*: the one-pixel contour of the final mask, used for c."""
    m = mask > 0.5
    return (m & ~ndimage.binary_erosion(m, np.ones((3, 3), bool))).astype(bool)


def boundary_confidence(e_hat: np.ndarray, mask: np.ndarray) -> float:
    """c = (1/|dM*|) * sum_{dM*} E_hat, averaged over the predicted contour.

    Line 49 of Algorithm 1(b). This is the inference-path confidence; its
    differentiable surrogate is :func:`soft_confidence`.
    """
    e = np.asarray(e_hat, np.float32)
    if e.ndim == 3:
        e = e[..., 0]
    contour = mask_contour(mask)
    if not contour.any():
        return 0.0
    return float(e[contour].mean())


def soft_confidence(e_hat: tf.Tensor) -> tf.Tensor:
    """c_soft = sum_Omega(E_hat * E_hat) / sum_Omega(E_hat), per sample.

    Weighting E_hat by itself rather than restricting the average to a
    thresholded contour. c_soft converges to c as E_hat approaches a binary
    indicator of the boundary (Section 3.6, 'Training path').
    """
    num = tf.reduce_sum(e_hat * e_hat, axis=[1, 2, 3])
    den = tf.reduce_sum(e_hat, axis=[1, 2, 3]) + _EPS
    return num / den


# --------------------------------------------------------------------------
# The five-channel classifier input (Section 3.6, 'Feature-level coupling')
# --------------------------------------------------------------------------
def classifier_input_soft(i_smooth: tf.Tensor, r_hat: tf.Tensor,
                          e_hat: tf.Tensor) -> tf.Tensor:
    """Training tensor [I_smooth (*) R_hat, E_hat, c_soft * 1].

    M_soft = R_hat is the *unthresholded* region map, so the classification
    gradient reaches the segmentation network through it.
    """
    masked = i_smooth * r_hat
    c = soft_confidence(e_hat)
    c_map = tf.ones_like(e_hat) * tf.reshape(c, [-1, 1, 1, 1])
    return tf.concat([masked, e_hat, c_map], axis=-1)


def classifier_input_hard(i_smooth: np.ndarray, mask: np.ndarray,
                          e_hat: np.ndarray) -> np.ndarray:
    """Inference tensor [I_smooth (*) M*_lesion, E_hat, c * 1].

    This is the path that produces every number reported in Section 4.
    """
    i = np.asarray(i_smooth, np.float32)
    m = np.asarray(mask, np.float32)
    if m.ndim == 2:
        m = m[..., None]
    e = np.asarray(e_hat, np.float32)
    if e.ndim == 2:
        e = e[..., None]
    c = boundary_confidence(e, m[..., 0])
    c_map = np.full_like(e, c, dtype=np.float32)
    return np.concatenate([i * m, e, c_map], axis=-1).astype(np.float32)
