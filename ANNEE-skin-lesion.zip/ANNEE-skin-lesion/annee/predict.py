"""Write the prediction artefacts that Section 3.12 releases.

Everything the paper reports for its own models is recomputed from these
files, without retraining:

    predictions/<run>/segmentation/
        masks/<image_id>.png          256x256 binary mask, the thresholded,
                                      morphologically refined M*_lesion
        region_prob/<image_id>.npy    raw R_hat before thresholding
        boundary_prob/<image_id>.npy  raw E_hat
        manifest.json                 which checkpoint produced these

    predictions/<run>/classification/
        predictions.csv               image_id, true, pred, p_0 ... p_{K-1}
        manifest.json

The manifest is what makes Reviewer 2's first request answerable from the
artefacts alone: it records the stage, the archive the checkpoint was
fine-tuned on, and the variant.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import tensorflow as tf

from .postprocess import (inference_mask, boundary_confidence,
                          classifier_input_hard)


def _save_png(path: Path, mask: np.ndarray):
    from PIL import Image
    Image.fromarray((np.asarray(mask) > 0.5).astype(np.uint8) * 255).save(path)


def predict_segmentation(seg_model, samples, out_dir, *, stage: str,
                         archive: str | None, variant: str,
                         use_morphology: bool = True,
                         save_probabilities: bool = True) -> Path:
    """Run the inference path over the ISIC 2018 Task 1 test split.

    ``stage`` must be 'stage1' or 'stage3' and ``archive`` names the
    classification archive a Stage-3 checkpoint was fine-tuned on. Both are
    written into the manifest, because Table 9 reports different checkpoints
    for different rows and the distinction must survive in the artefacts.
    """
    out = Path(out_dir)
    (out / 'masks').mkdir(parents=True, exist_ok=True)
    if save_probabilities:
        (out / 'region_prob').mkdir(parents=True, exist_ok=True)
        (out / 'boundary_prob').mkdir(parents=True, exist_ok=True)

    written = []
    for s in samples:
        e_hat, r_hat, _ = seg_model([s['i_sm'][None], s['e0'][None]],
                                    training=False)
        e_hat = np.asarray(e_hat)[0]
        r_hat = np.asarray(r_hat)[0]
        mask = inference_mask(r_hat, use_morphology=use_morphology)
        _save_png(out / 'masks' / f"{s['image_id']}.png", mask)
        if save_probabilities:
            np.save(out / 'region_prob' / f"{s['image_id']}.npy",
                    r_hat.astype(np.float16))
            np.save(out / 'boundary_prob' / f"{s['image_id']}.npy",
                    e_hat.astype(np.float16))
        written.append(s['image_id'])

    (out / 'manifest.json').write_text(json.dumps({
        'kind': 'segmentation',
        'variant': variant,
        'checkpoint_stage': stage,
        'finetuned_on': archive,
        'morphology_applied': bool(use_morphology),
        'n_images': len(written),
        'image_ids': written,
        'note': ('Table 9 evaluates the Stage-3 checkpoint for every variant '
                 'except "w/o joint fine-tuning", which is Stage 1.'),
    }, indent=2), encoding='utf-8')
    return out


def predict_classification(seg_model, cls_model, samples, out_dir, *,
                           stage: str, archive: str, variant: str,
                           class_names, use_morphology: bool = True) -> Path:
    """Run the inference path over a classification test split.

    The classifier consumes the *hard* five-channel tensor here - masked
    colour channels from M*_lesion, E_hat and the contour-averaged confidence
    c - which is the path that produces every number in Section 4.
    """
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    rows = []
    for s in samples:
        e_hat, r_hat, _ = seg_model([s['i_sm'][None], s['e0'][None]],
                                    training=False)
        e_hat = np.asarray(e_hat)[0]
        r_hat = np.asarray(r_hat)[0]
        mask = inference_mask(r_hat, use_morphology=use_morphology)
        x = classifier_input_hard(s['i_sm'], mask, e_hat)
        p = np.asarray(cls_model(x[None], training=False))[0]
        rows.append({'image_id': s['image_id'], 'true': int(s['label']),
                     'pred': int(p.argmax()),
                     'confidence': boundary_confidence(e_hat, mask),
                     **{f'p_{i}': float(v) for i, v in enumerate(p)}})

    if not rows:
        raise ValueError(
            f'no test samples for {archive}: predictions.csv would be empty. '
            f'Check the split index - a held-out split must not be empty.')
    import pandas as pd
    pd.DataFrame(rows).to_csv(out / 'predictions.csv', index=False)
    (out / 'manifest.json').write_text(json.dumps({
        'kind': 'classification',
        'variant': variant,
        'checkpoint_stage': stage,
        'archive': archive,
        'class_names': list(class_names),
        'morphology_applied': bool(use_morphology),
        'n_images': len(rows),
        'note': ('Probabilities are the full softmax vector, so the AUC '
                 'columns are reproducible as well as the count-based metrics.'),
    }, indent=2), encoding='utf-8')
    return out


def load_classification_predictions(path):
    """Read back a predictions.csv as (y_true, probabilities, image_ids)."""
    import pandas as pd
    df = pd.read_csv(Path(path))
    cols = sorted((c for c in df.columns if c.startswith('p_')),
                  key=lambda c: int(c.split('_')[1]))
    return (df['true'].to_numpy(int), df[cols].to_numpy(float),
            df['image_id'].tolist())
