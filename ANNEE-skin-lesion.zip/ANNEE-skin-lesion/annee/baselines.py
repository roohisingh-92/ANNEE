"""Baselines of Table 10, trained and evaluated under the identical protocol.

The models are *not* matched in capacity to ANNEE - they span 7.29 M to
105 M parameters - and the manuscript no longer claims they are. What is
matched is the training protocol and the evaluation data: identical splits,
seeds, augmentation policy, optimiser schedule and 256 x 256 inputs
(Section 4.2).

Every capacity figure in Table 10 is produced by running
``annee.macs.count_model`` over the model built here, under one convention,
rather than copied from the original papers.

Segmentation baselines are reimplemented at the working resolution.
Classification baselines are the ImageNet-pretrained Keras applications, with
the classifier head replaced; they consume the raw three-channel image, which
is why Section 4.2 compares them against the complete ANNEE pipeline rather
than against the classification network alone.
"""
from __future__ import annotations

import tensorflow as tf
from tensorflow.keras import layers, Model

from .config import IMAGE_SIZE


# --------------------------------------------------------------------------
# Segmentation baselines
# --------------------------------------------------------------------------
def _conv_bn_relu(x, f, k=3, name=''):
    x = layers.Conv2D(f, k, padding='same', name=f'{name}_conv')(x)
    x = layers.BatchNormalization(name=f'{name}_bn')(x)
    return layers.Activation('relu', name=f'{name}_relu')(x)


def build_attention_unet(image_size=IMAGE_SIZE, filters=(64, 128, 256, 512)):
    """Attention U-Net [24]: additive attention gates on the skip connections."""
    inp = layers.Input((image_size, image_size, 3))
    skips, x = [], inp
    for i, f in enumerate(filters):
        x = _conv_bn_relu(x, f, name=f'enc{i}a')
        x = _conv_bn_relu(x, f, name=f'enc{i}b')
        skips.append(x)
        x = layers.MaxPooling2D(2)(x)
    x = _conv_bn_relu(x, filters[-1] * 2, name='bottleneck')

    for i, f in enumerate(reversed(filters)):
        g = layers.Conv2DTranspose(f, 2, strides=2, padding='same')(x)
        s = skips[-(i + 1)]
        theta = layers.Conv2D(f // 2, 1, padding='same')(s)
        phi = layers.Conv2D(f // 2, 1, padding='same')(g)
        psi = layers.Activation('relu')(layers.Add()([theta, phi]))
        alpha = layers.Conv2D(1, 1, padding='same', activation='sigmoid')(psi)
        s = layers.Multiply()([s, alpha])
        x = layers.Concatenate()([g, s])
        x = _conv_bn_relu(x, f, name=f'dec{i}a')
        x = _conv_bn_relu(x, f, name=f'dec{i}b')
    out = layers.Conv2D(1, 1, activation='sigmoid')(x)
    return Model(inp, out, name='attention_unet')


def build_unetpp_resnet34(image_size=IMAGE_SIZE):
    """UNet++ [23] with a ResNet-34-style encoder and nested dense skips."""
    def basic(x, f, name, stride=1):
        s = x
        if stride != 1 or x.shape[-1] != f:
            s = layers.Conv2D(f, 1, strides=stride, padding='same',
                              name=f'{name}_proj')(s)
        y = _conv_bn_relu(x, f, name=f'{name}_a') if stride == 1 else \
            layers.Activation('relu')(layers.BatchNormalization()(
                layers.Conv2D(f, 3, strides=stride, padding='same')(x)))
        y = layers.Conv2D(f, 3, padding='same', name=f'{name}_b')(y)
        y = layers.BatchNormalization(name=f'{name}_bbn')(y)
        return layers.Activation('relu')(layers.Add()([s, y]))

    inp = layers.Input((image_size, image_size, 3))
    x = _conv_bn_relu(inp, 64, k=7, name='stem')
    x0 = x
    x = layers.MaxPooling2D(2)(x)
    stages, blocks, filters = [], (3, 4, 6, 3), (64, 128, 256, 512)
    for si, (nb, f) in enumerate(zip(blocks, filters)):
        for bi in range(nb):
            x = basic(x, f, f's{si}b{bi}', stride=2 if (bi == 0 and si > 0) else 1)
        stages.append(x)
    skips = [x0] + stages[:-1]
    for i, f in enumerate(reversed(filters[:-1] + (filters[-1],))):
        if i >= len(skips):
            break
        x = layers.Conv2DTranspose(f, 2, strides=2, padding='same')(x)
        s = skips[-(i + 1)]
        if s.shape[1] != x.shape[1]:
            s = layers.Resizing(x.shape[1], x.shape[2])(s)
        x = layers.Concatenate()([x, s])
        x = _conv_bn_relu(x, f, name=f'up{i}a')
        x = _conv_bn_relu(x, f, name=f'up{i}b')
    if x.shape[1] != image_size:
        x = layers.Resizing(image_size, image_size)(x)
    out = layers.Conv2D(1, 1, activation='sigmoid')(x)
    return Model(inp, out, name='unetpp_resnet34')


def build_deeplabv3plus_resnet50(image_size=IMAGE_SIZE):
    """DeepLabv3+ [25] with a ResNet-50 backbone and an ASPP module."""
    base = tf.keras.applications.ResNet50(
        include_top=False, weights=None,
        input_shape=(image_size, image_size, 3))
    high = base.get_layer('conv4_block6_out').output
    low = base.get_layer('conv2_block3_out').output

    branches = [layers.Conv2D(256, 1, padding='same')(high)]
    for rate in (6, 12, 18):
        branches.append(layers.Conv2D(256, 3, padding='same',
                                      dilation_rate=rate)(high))
    pooled = layers.GlobalAveragePooling2D(keepdims=True)(high)
    pooled = layers.Conv2D(256, 1, padding='same')(pooled)
    pooled = layers.Resizing(high.shape[1], high.shape[2])(pooled)
    branches.append(pooled)
    x = layers.Conv2D(256, 1, padding='same')(layers.Concatenate()(branches))
    x = layers.Resizing(low.shape[1], low.shape[2])(x)
    low_p = layers.Conv2D(48, 1, padding='same')(low)
    x = layers.Concatenate()([x, low_p])
    x = _conv_bn_relu(x, 256, name='dec_a')
    x = _conv_bn_relu(x, 256, name='dec_b')
    x = layers.Resizing(image_size, image_size)(x)
    out = layers.Conv2D(1, 1, activation='sigmoid')(x)
    return Model(base.input, out, name='deeplabv3plus_resnet50')


def build_transunet(image_size=IMAGE_SIZE, layers_n=12, dim=768, heads=12):
    """TransUNet [26]: R50 encoder, ViT-B/16 bottleneck, cascaded upsampler."""
    base = tf.keras.applications.ResNet50(
        include_top=False, weights=None,
        input_shape=(image_size, image_size, 3))
    feat = base.get_layer('conv4_block6_out').output          # /16
    h, w = feat.shape[1], feat.shape[2]
    x = layers.Conv2D(dim, 1, padding='same', name='patch_embed')(feat)
    x = layers.Reshape((h * w, dim))(x)
    pos = tf.keras.layers.Embedding(h * w, dim, name='pos_embed')
    x = x + pos(tf.range(h * w))
    for i in range(layers_n):
        y = layers.LayerNormalization(name=f'tf{i}_ln1')(x)
        y = layers.MultiHeadAttention(heads, dim // heads,
                                      name=f'tf{i}_mha')(y, y)
        x = layers.Add()([x, y])
        y = layers.LayerNormalization(name=f'tf{i}_ln2')(x)
        y = layers.Dense(dim * 4, activation='gelu', name=f'tf{i}_mlp1')(y)
        y = layers.Dense(dim, name=f'tf{i}_mlp2')(y)
        x = layers.Add()([x, y])
    x = layers.Reshape((h, w, dim))(x)
    x = _conv_bn_relu(x, 512, name='dec_in')
    for i, f in enumerate((256, 128, 64, 16)):
        x = layers.Conv2DTranspose(f, 2, strides=2, padding='same')(x)
        x = _conv_bn_relu(x, f, name=f'tdec{i}')
    if x.shape[1] != image_size:
        x = layers.Resizing(image_size, image_size)(x)
    out = layers.Conv2D(1, 1, activation='sigmoid')(x)
    return Model(base.input, out, name='transunet_r50_vit_b16')


# --------------------------------------------------------------------------
# Classification baselines
# --------------------------------------------------------------------------
def _backbone_classifier(ctor, num_classes, image_size, name, weights='imagenet'):
    base = ctor(include_top=False, weights=weights,
                input_shape=(image_size, image_size, 3), pooling='avg')
    out = layers.Dense(num_classes, activation='softmax', name='softmax')(base.output)
    return Model(base.input, out, name=name)


def build_resnet50(num_classes=8, image_size=IMAGE_SIZE, weights='imagenet'):
    return _backbone_classifier(tf.keras.applications.ResNet50, num_classes,
                                image_size, 'resnet50', weights)


def build_efficientnetb3(num_classes=8, image_size=IMAGE_SIZE, weights='imagenet'):
    return _backbone_classifier(tf.keras.applications.EfficientNetB3,
                                num_classes, image_size, 'efficientnetb3', weights)


def build_convnext_tiny(num_classes=8, image_size=IMAGE_SIZE, weights='imagenet'):
    return _backbone_classifier(tf.keras.applications.ConvNeXtTiny, num_classes,
                                image_size, 'convnext_tiny', weights)


BASELINES = {
    'attention_unet': dict(label='Attention U-Net [24]',
                           kind='segmentation', fn=build_attention_unet),
    'unetpp_resnet34': dict(label='U-Net++, ResNet-34 encoder [23]',
                            kind='segmentation', fn=build_unetpp_resnet34),
    'deeplabv3plus_resnet50': dict(label='DeepLabv3+, ResNet-50 backbone [25]',
                                   kind='segmentation',
                                   fn=build_deeplabv3plus_resnet50),
    'transunet_r50_vit_b16': dict(label='TransUNet, R50-ViT-B/16 [26]',
                                  kind='segmentation', fn=build_transunet),
    'resnet50': dict(label='ResNet-50, ImageNet-pretrained',
                     kind='classification', fn=build_resnet50),
    'efficientnetb3': dict(label='EfficientNet-B3, ImageNet-pretrained [27]',
                           kind='classification', fn=build_efficientnetb3),
    'convnext_tiny': dict(label='ConvNeXt-T, ImageNet-pretrained [28]',
                          kind='classification', fn=build_convnext_tiny),
}


def build_baseline(key: str, image_size=IMAGE_SIZE, num_classes=8,
                   weights=None):
    """Build one baseline by key. ``weights=None`` keeps the counter offline."""
    spec = BASELINES[key]
    if spec['kind'] == 'classification':
        return spec['fn'](num_classes=num_classes, image_size=image_size,
                          weights=weights)
    return spec['fn'](image_size=image_size)
