"""Segmentation and classification metrics.

All definitions follow Section 3.11, 'Evaluation metrics and statistical
methodology'. Everything here operates on *saved predictions*, never on a
live model, so that Tables 4, 5, 7, 9 and the ANNEE rows of Table 10 can be
recomputed from the released artefacts without retraining.
"""
from __future__ import annotations

import numpy as np
from scipy import ndimage
from scipy.spatial import cKDTree

from .config import BOUNDARY_F_TOLERANCE_PX, HD_PERCENTILE

_EPS = 1e-8


# ==========================================================================
# Segmentation
# ==========================================================================
def _binary(a) -> np.ndarray:
    a = np.asarray(a)
    if a.ndim == 3 and a.shape[-1] == 1:
        a = a[..., 0]
    return a > 0.5


def dice(pred, true) -> float:
    p, t = _binary(pred), _binary(true)
    s = p.sum() + t.sum()
    if s == 0:
        return 1.0
    return float(2.0 * (p & t).sum() / s)


def iou(pred, true) -> float:
    p, t = _binary(pred), _binary(true)
    union = (p | t).sum()
    if union == 0:
        return 1.0
    return float((p & t).sum() / union)


def sensitivity(pred, true) -> float:
    p, t = _binary(pred), _binary(true)
    denom = t.sum()
    return 1.0 if denom == 0 else float((p & t).sum() / denom)


def specificity(pred, true) -> float:
    p, t = _binary(pred), _binary(true)
    denom = (~t).sum()
    return 1.0 if denom == 0 else float((~p & ~t).sum() / denom)


def _contour_points(mask: np.ndarray) -> np.ndarray:
    m = _binary(mask)
    edge = m & ~ndimage.binary_erosion(m, np.ones((3, 3), bool))
    return np.argwhere(edge).astype(np.float64)


def boundary_f_score(pred, true, tolerance: int = BOUNDARY_F_TOLERANCE_PX) -> float:
    """Boundary F-score with a 2-pixel tolerance (Section 3.11).

    A predicted contour point counts as a hit when it lies within
    ``tolerance`` pixels of a ground-truth contour point, and vice versa.
    """
    pc, tc = _contour_points(pred), _contour_points(true)
    if len(pc) == 0 and len(tc) == 0:
        return 1.0
    if len(pc) == 0 or len(tc) == 0:
        return 0.0
    d_pt = cKDTree(tc).query(pc)[0]
    d_tp = cKDTree(pc).query(tc)[0]
    precision = float((d_pt <= tolerance).mean())
    recall = float((d_tp <= tolerance).mean())
    if precision + recall == 0:
        return 0.0
    return 2.0 * precision * recall / (precision + recall)


def hausdorff_percentile(pred, true, percentile: int = HD_PERCENTILE) -> float:
    """HD95: the 95th percentile of the symmetric contour distance."""
    pc, tc = _contour_points(pred), _contour_points(true)
    if len(pc) == 0 or len(tc) == 0:
        return float('nan')
    d_pt = cKDTree(tc).query(pc)[0]
    d_tp = cKDTree(pc).query(tc)[0]
    return float(np.percentile(np.concatenate([d_pt, d_tp]), percentile))


SEG_METRICS = ('dice', 'iou', 'sensitivity', 'specificity', 'boundary_f', 'hd95')


def segmentation_metrics(pred, true) -> dict[str, float]:
    """All six columns of Table 9 for one image."""
    return {
        'dice': dice(pred, true),
        'iou': iou(pred, true),
        'sensitivity': sensitivity(pred, true),
        'specificity': specificity(pred, true),
        'boundary_f': boundary_f_score(pred, true),
        'hd95': hausdorff_percentile(pred, true),
    }


def aggregate_segmentation(per_image: list[dict]) -> dict[str, float]:
    """Mean over the test images, as Table 9 reports."""
    return {k: float(np.nanmean([m[k] for m in per_image])) for k in SEG_METRICS}


# ==========================================================================
# Classification
# ==========================================================================
def confusion_matrix(y_true: np.ndarray, y_pred: np.ndarray,
                     num_classes: int) -> np.ndarray:
    """Argmax confusion matrix, rows = true class (Fig. 2, Table 5)."""
    cm = np.zeros((num_classes, num_classes), np.int64)
    for t, p in zip(np.asarray(y_true, int), np.asarray(y_pred, int)):
        cm[t, p] += 1
    return cm


def audit_confusion(cm: np.ndarray) -> dict:
    """Table 5: support (row sum), predicted (column sum), correct (diagonal).

    Every count-based metric of Table 4 is recomputable from these numbers,
    which is what the audit is for.
    """
    return {
        'support': cm.sum(1).tolist(),
        'predicted': cm.sum(0).tolist(),
        'correct': np.diag(cm).tolist(),
        'total': int(cm.sum()),
        'diagonal_sum': int(np.trace(cm)),
        'overall_accuracy': float(np.trace(cm) / max(1, cm.sum())),
    }


def per_class_metrics(cm: np.ndarray) -> dict[str, list[float]]:
    """One-vs-rest accuracy, precision, recall and F1 per class (Table 4)."""
    total = cm.sum()
    acc, prec, rec, f1 = [], [], [], []
    for k in range(cm.shape[0]):
        tp = cm[k, k]
        fp = cm[:, k].sum() - tp
        fn = cm[k, :].sum() - tp
        tn = total - tp - fp - fn
        acc.append(float((tp + tn) / max(1, total)))
        p = tp / (tp + fp) if tp + fp else 0.0
        r = tp / (tp + fn) if tp + fn else 0.0
        prec.append(float(p))
        rec.append(float(r))
        f1.append(float(2 * p * r / (p + r)) if p + r else 0.0)
    return {'accuracy': acc, 'precision': prec, 'recall': rec, 'f1': f1}


def roc_auc_ovr(y_true: np.ndarray, probabilities: np.ndarray) -> list[float]:
    """One-vs-rest ROC AUC per class; needs the full probability vectors."""
    from sklearn.metrics import roc_auc_score
    y = np.asarray(y_true, int)
    out = []
    for k in range(probabilities.shape[1]):
        binary = (y == k).astype(int)
        if binary.min() == binary.max():
            out.append(float('nan'))
        else:
            out.append(float(roc_auc_score(binary, probabilities[:, k])))
    return out


def classification_report(y_true: np.ndarray, probabilities: np.ndarray,
                          num_classes: int) -> dict:
    """Everything Tables 4, 5 and 7 need, from saved predictions alone."""
    y_pred = probabilities.argmax(1)
    cm = confusion_matrix(y_true, y_pred, num_classes)
    per_class = per_class_metrics(cm)
    auc = roc_auc_ovr(y_true, probabilities)
    return {
        'confusion_matrix': cm.tolist(),
        'audit': audit_confusion(cm),
        'per_class': {**per_class, 'auc': auc},
        'overall_accuracy': float(np.trace(cm) / max(1, cm.sum())),
        'macro_precision': float(np.mean(per_class['precision'])),
        'macro_recall': float(np.mean(per_class['recall'])),
        'macro_f1': float(np.mean(per_class['f1'])),
        'macro_auc': float(np.nanmean(auc)),
    }
