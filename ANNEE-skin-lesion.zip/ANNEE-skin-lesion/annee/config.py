"""Configuration for the ANNEE framework.

Every constant here is the value stated in the manuscript. The section or
equation that fixes each one is given in the comment, so that a reader can
check the code against the paper without reading the whole module.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Sequence
import json


# --------------------------------------------------------------------------
# Preprocessing (Sections 3.2.2 - 3.2.5, 3.12)
# --------------------------------------------------------------------------
IMAGE_SIZE = 256                 # Section 3.2.2, working resolution 256 x 256
GAUSSIAN_SIGMA = 1.0             # Section 3.2.4
BT601 = (0.299, 0.587, 0.114)    # Section 3.12, luma weights for Sobel
BOUNDARY_RADIUS_RHO = 1          # Section 3.2.7, E_true band thickness t = 2*rho

# Post-processing, inference only (Sections 3.6, 3.7, 3.12)
MORPH_DISK_RADIUS = 5            # Section 3.11, disk-shaped structuring element
OTSU_BINS = 256                  # Section 3.12
CONNECTIVITY = 8                 # Section 3.12, 8-connectivity

# --------------------------------------------------------------------------
# Architecture (Section 3.11, reproduces Table 2 exactly)
# --------------------------------------------------------------------------
ENCODER_FILTERS: Sequence[int] = (32, 64, 128, 256)
BOTTLENECK_FILTERS = 512
DECODER_FILTERS: Sequence[int] = (256, 128, 64, 32)
CLASSIFIER_FILTERS: Sequence[int] = (32, 64, 128, 256)
CLASSIFIER_DENSE = 256
CLASSIFIER_DROPOUT = 0.5
GATE_KERNEL = 3                  # Section 3.5, single 3x3 conv over 4 channels
CLASSIFIER_INPUT_CHANNELS = 5    # Section 3.6: 3 masked colour + E_hat + confidence

# --------------------------------------------------------------------------
# Optimisation (Sections 3.11, 3.12)
# --------------------------------------------------------------------------
ADAM_BETA_1 = 0.9
ADAM_BETA_2 = 0.999
BATCH_SIZE = 16
LR_STAGE12 = 1e-4                # Section 3.11
LR_PLATEAU_FACTOR = 0.1          # "reduced by a factor of 10 on validation plateau"
LR_PLATEAU_PATIENCE = 5
MAX_EPOCHS = 100
EARLY_STOPPING_PATIENCE = 15

LR_STAGE3 = 1e-5                 # Section 3.12, joint fine-tuning schedule
STAGE3_EPOCHS = 20
STAGE3_PATIENCE = 5
LAMBDA_CLASS = 1.0               # Eq. (15c)

# Learnable log-variances of Eq. (15a)/(15c) (Sections 3.3.4, 3.5)
S_INIT = 0.0                     # both initialised at zero -> shares start at 0.5
DICE_SMOOTH = 1.0                # Section 3.3.3, smoothing constant

# Augmentation (Section 3.11)
AUG_ROTATION_DEG = 30.0
AUG_SCALE = 0.10
AUG_BRIGHTNESS = 0.10

SEEDS: Sequence[int] = (0, 1, 2, 3, 4)   # Section 3.12
SPLIT_FRACTIONS = (0.8, 0.1, 0.1)        # Section 3.11, train / val / test

# --------------------------------------------------------------------------
# Datasets (Sections 3.10, 3.11, Table 3)
# --------------------------------------------------------------------------
ISIC2019_CLASSES = ('MEL', 'NV', 'BCC', 'AK', 'BKL', 'DF', 'VASC', 'SCC')
HAM10000_CLASSES = ('akiec', 'bcc', 'bkl', 'df', 'mel', 'nv', 'vasc')

DATASETS = {
    'isic2018': dict(task='segmentation', supervision='mask'),
    'isic2019': dict(task='classification', classes=ISIC2019_CLASSES),
    'ham10000': dict(task='classification', classes=HAM10000_CLASSES),
}

# Statistics (Section 3.11)
BOOTSTRAP_RESAMPLES = 1000
BOUNDARY_F_TOLERANCE_PX = 2      # Section 3.11, boundary F-score tolerance
HD_PERCENTILE = 95               # HD95


@dataclass
class RunConfig:
    """One experimental run: a variant, a seed and the archive it trains on."""

    variant: str = 'A'                 # see annee.variants.VARIANTS
    seed: int = 0
    dataset: str = 'isic2019'          # classification archive for Stages 2-3
    seg_dataset: str = 'isic2018'      # pixel-level supervision, Stage 1 only
    data_root: str = 'data'
    out_root: str = 'artifacts'
    image_size: int = IMAGE_SIZE
    batch_size: int = BATCH_SIZE
    max_epochs: int = MAX_EPOCHS
    stage3_epochs: int = STAGE3_EPOCHS
    lambda_class: float = LAMBDA_CLASS
    fixed_weights: tuple | None = None  # (alpha, beta) for variants J-L, else None
    use_edge_channel: bool = True       # variant C removes it
    use_attention_gate: bool = True     # variant B removes it
    use_edge_loss: bool = True          # variant D sets alpha = 0
    edge_operator: str = 'sobel'        # variant E uses 'canny'
    use_morphology: bool = True         # variant F removes it
    use_joint_finetuning: bool = True   # variant G removes Stage 3
    use_augmentation: bool = True       # variant H removes it
    vanilla_unet: bool = False          # variant I

    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=2, sort_keys=True)

    @property
    def num_classes(self) -> int:
        return len(DATASETS[self.dataset]['classes'])

    @property
    def tag(self) -> str:
        return f'{self.variant}_{self.dataset}_seed{self.seed}'
