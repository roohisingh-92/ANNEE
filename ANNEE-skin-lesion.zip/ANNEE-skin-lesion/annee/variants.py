"""The ablation variants of Table 7 and Table 9, and the baselines of Table 10.

Each entry returns the keyword overrides applied to :class:`annee.config.RunConfig`.
Every variant is trained and evaluated on identical splits and seeds; only the
listed field changes.
"""
from __future__ import annotations

VARIANTS: dict[str, dict] = {
    # label -> (description, config overrides)
    'A': dict(description='Full ANNEE (adaptive fusion + joint fine-tuning)',
              overrides={}),
    'B': dict(description='w/o adaptive gate (fixed concatenation of E_0)',
              overrides=dict(use_attention_gate=False)),
    'C': dict(description='w/o edge channel',
              overrides=dict(use_edge_channel=False, use_edge_loss=False)),
    'D': dict(description='w/o edge-preservation loss (alpha = 0)',
              overrides=dict(use_edge_loss=False)),
    'E': dict(description='Canny instead of Sobel',
              overrides=dict(edge_operator='canny')),
    'F': dict(description='w/o morphological post-processing',
              overrides=dict(use_morphology=False)),
    'G': dict(description='w/o joint fine-tuning (independent stages)',
              overrides=dict(use_joint_finetuning=False)),
    'H': dict(description='w/o data augmentation',
              overrides=dict(use_augmentation=False)),
    'I': dict(description='Vanilla U-Net + CNN baseline',
              overrides=dict(vanilla_unet=True, use_edge_channel=False,
                             use_attention_gate=False, use_edge_loss=False)),
    'J': dict(description='Fixed weights (alpha, beta) = (0.5, 0.5)',
              overrides=dict(fixed_weights=(0.5, 0.5))),
    'K': dict(description='Fixed weights (alpha, beta) = (0.3, 0.7)',
              overrides=dict(fixed_weights=(0.3, 0.7))),
    'L': dict(description='Fixed weights (alpha, beta) = (0.7, 0.3)',
              overrides=dict(fixed_weights=(0.7, 0.3))),
}

#: Variants that have no Stage 3 and are therefore evaluated at the Stage-1
#: checkpoint in Table 9. Every other variant is evaluated at Stage 3.
STAGE1_ONLY = frozenset({'G'})


def checkpoint_stage(variant: str) -> str:
    """Which checkpoint Table 9 reports for a variant.

    This is the function behind the Table 9 caption: 'Every variant is
    evaluated at its Stage-3 checkpoint, jointly fine-tuned on ISIC 2019 under
    Eq. (15c), with the single exception of the "w/o joint fine-tuning" row,
    which is the Stage-1 checkpoint of the full model.'
    """
    return 'stage1' if variant in STAGE1_ONLY else 'stage3'


def apply_variant(cfg, variant: str):
    """Return a copy of ``cfg`` with the variant's overrides applied."""
    import dataclasses
    if variant not in VARIANTS:
        raise KeyError(f'unknown variant {variant!r}; '
                       f'known: {sorted(VARIANTS)}')
    return dataclasses.replace(cfg, variant=variant,
                               **VARIANTS[variant]['overrides'])


#: Table 10. Segmentation baselines are reimplemented at 256 x 256 and trained
#: under the identical protocol of Section 3.11; classification baselines are
#: the ImageNet-pretrained backbones. Parameter and MAC figures for every row
#: are produced by ``scripts/count_macs.py``, never copied from the papers.
SEGMENTATION_BASELINES = ('unet', 'attention_unet', 'unetpp_resnet34',
                          'deeplabv3plus_resnet50', 'transunet_r50_vit_b16')
CLASSIFICATION_BASELINES = ('resnet50', 'efficientnetb3', 'convnext_tiny')
