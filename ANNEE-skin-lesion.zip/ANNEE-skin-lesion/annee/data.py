"""Dataset loading, augmentation and tf.data pipelines.

Expected layout under ``--data-root`` (the archives are not redistributed
here; see ``docs/DATA.md`` for where to obtain each one):

    data/
      isic2018/metadata.csv        image_id, lesion_id[, isic_id]
      isic2018/images/<image_id>.jpg
      isic2018/masks/<image_id>_segmentation.png
      isic2019/metadata.csv        image_id, lesion_id, label[, isic_id]
      isic2019/images/<image_id>.jpg
      ham10000/metadata.csv        image_id, lesion_id, label[, isic_id]
      ham10000/images/<image_id>.jpg

Augmentation is the policy of Section 3.11: random horizontal and vertical
flips, rotations of +-30 degrees, scaling of +-10% and brightness jitter of
+-10%. It is applied to the training split only, and identically to the image
and its mask. Ablation variant (H) switches it off.
"""
from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import tensorflow as tf

from .config import (IMAGE_SIZE, BATCH_SIZE, AUG_ROTATION_DEG, AUG_SCALE,
                     AUG_BRIGHTNESS, DATASETS)
from .preprocessing import np_preprocess, np_resize_mask, np_boundary_target


# --------------------------------------------------------------------------
# Disk access
# --------------------------------------------------------------------------
def _read_image(path: str | Path) -> np.ndarray:
    from PIL import Image
    with Image.open(path) as im:
        return np.asarray(im.convert('RGB'), np.float32) / 255.0


def _read_mask(path: str | Path) -> np.ndarray:
    from PIL import Image
    with Image.open(path) as im:
        return (np.asarray(im.convert('L'), np.float32) / 255.0 > 0.5).astype(np.float32)


def image_path(root: str | Path, dataset: str, image_id: str) -> Path:
    base = Path(root) / dataset / 'images'
    for ext in ('.jpg', '.jpeg', '.png', '.JPG'):
        p = base / f'{image_id}{ext}'
        if p.exists():
            return p
    raise FileNotFoundError(f'{dataset}/{image_id}: no image file found')


def mask_path(root: str | Path, image_id: str) -> Path:
    base = Path(root) / 'isic2018' / 'masks'
    for pattern in (f'{image_id}_segmentation.png', f'{image_id}.png'):
        p = base / pattern
        if p.exists():
            return p
    raise FileNotFoundError(f'isic2018/{image_id}: no mask file found')


# --------------------------------------------------------------------------
# Sample construction
# --------------------------------------------------------------------------
def make_segmentation_sample(root, image_id: str, size: int = IMAGE_SIZE,
                             operator: str = 'sobel', rho: int = 1) -> dict:
    """One ISIC 2018 Task 1 sample: I_sm, E_0, M_true and E_true."""
    i_sm, e0 = np_preprocess(_read_image(image_path(root, 'isic2018', image_id)),
                             size, operator=operator)
    m = np_resize_mask(_read_mask(mask_path(root, image_id)), size)
    return {'image_id': image_id, 'i_sm': i_sm, 'e0': e0[..., None],
            'm_true': m[..., None],
            'e_true': np_boundary_target(m, rho)[..., None]}


def make_classification_sample(root, dataset: str, image_id: str, label: int,
                               size: int = IMAGE_SIZE,
                               operator: str = 'sobel') -> dict:
    """One classification sample: no mask exists for these archives."""
    i_sm, e0 = np_preprocess(_read_image(image_path(root, dataset, image_id)),
                             size, operator=operator)
    return {'image_id': image_id, 'i_sm': i_sm, 'e0': e0[..., None],
            'label': int(label)}


# --------------------------------------------------------------------------
# Augmentation (Section 3.11)
# --------------------------------------------------------------------------
def _affine(image: tf.Tensor, angle: tf.Tensor, scale: tf.Tensor,
            interpolation: str) -> tf.Tensor:
    """Rotate and scale about the image centre with a single affine warp."""
    h = tf.cast(tf.shape(image)[1], tf.float32)
    w = tf.cast(tf.shape(image)[2], tf.float32)
    cos = tf.cos(angle) / scale
    sin = tf.sin(angle) / scale
    cx, cy = w / 2.0, h / 2.0
    tx = cx - cx * cos + cy * sin
    ty = cy - cx * sin - cy * cos
    zero = tf.zeros_like(cos)
    mat = tf.stack([cos, -sin, tx, sin, cos, ty, zero, zero], axis=-1)
    mat = tf.reshape(mat, [-1, 8])
    n = tf.shape(image)[0]
    if tf.shape(mat)[0] == 1:
        mat = tf.tile(mat, [n, 1])
    try:
        from tensorflow.raw_ops import ImageProjectiveTransformV3
        return ImageProjectiveTransformV3(
            images=image, transforms=mat, output_shape=tf.shape(image)[1:3],
            interpolation=interpolation.upper(), fill_mode='REFLECT',
            fill_value=0.0)
    except Exception:                                    # pragma: no cover
        return image


def augment(i_sm: tf.Tensor, extras: dict[str, tf.Tensor],
            seed: int | None = None) -> tuple[tf.Tensor, dict]:
    """Flips, +-30 deg rotation, +-10% scale, +-10% brightness.

    Geometric transforms are applied identically to the image and to every
    tensor in ``extras`` (E_0, M_true, E_true); brightness jitter applies to
    the image only. Masks use nearest-neighbour interpolation so they stay
    binary.
    """
    g = tf.random.Generator.from_seed(seed) if seed is not None \
        else tf.random.get_global_generator()

    if g.uniform([]) < 0.5:
        i_sm = tf.image.flip_left_right(i_sm)
        extras = {k: tf.image.flip_left_right(v) for k, v in extras.items()}
    if g.uniform([]) < 0.5:
        i_sm = tf.image.flip_up_down(i_sm)
        extras = {k: tf.image.flip_up_down(v) for k, v in extras.items()}

    angle = g.uniform([1], -AUG_ROTATION_DEG, AUG_ROTATION_DEG) * math.pi / 180.0
    scale = g.uniform([1], 1.0 - AUG_SCALE, 1.0 + AUG_SCALE)
    i_sm = _affine(i_sm, angle, scale, 'bilinear')
    out = {}
    for k, v in extras.items():
        mode = 'nearest' if k in ('m_true', 'e_true') else 'bilinear'
        out[k] = _affine(v, angle, scale, mode)

    delta = g.uniform([], -AUG_BRIGHTNESS, AUG_BRIGHTNESS)
    i_sm = tf.clip_by_value(i_sm + delta, 0.0, 1.0)
    return i_sm, out


# --------------------------------------------------------------------------
# tf.data pipelines
# --------------------------------------------------------------------------
def segmentation_dataset(root, image_ids, size=IMAGE_SIZE, batch=BATCH_SIZE,
                         training=False, use_augmentation=True,
                         operator='sobel', rho=1, seed=0) -> tf.data.Dataset:
    """Stage-1 pipeline: yields (i_sm, e0, m_true, e_true)."""
    ids = list(image_ids)

    def gen():
        order = np.random.default_rng(seed).permutation(len(ids)) if training \
            else np.arange(len(ids))
        for i in order:
            s = make_segmentation_sample(root, ids[i], size, operator, rho)
            yield s['i_sm'], s['e0'], s['m_true'], s['e_true']

    sig = (tf.TensorSpec((size, size, 3), tf.float32),
           tf.TensorSpec((size, size, 1), tf.float32),
           tf.TensorSpec((size, size, 1), tf.float32),
           tf.TensorSpec((size, size, 1), tf.float32))
    ds = tf.data.Dataset.from_generator(gen, output_signature=sig).batch(batch)
    if training and use_augmentation:
        def _aug(i, e0, m, et):
            i, ex = augment(i, {'e0': e0, 'm_true': m, 'e_true': et})
            return i, ex['e0'], ex['m_true'], ex['e_true']
        ds = ds.map(_aug, num_parallel_calls=tf.data.AUTOTUNE)
    return ds.prefetch(tf.data.AUTOTUNE)


def classification_dataset(root, dataset, image_ids, labels, num_classes,
                           size=IMAGE_SIZE, batch=BATCH_SIZE, training=False,
                           use_augmentation=True, operator='sobel',
                           seed=0) -> tf.data.Dataset:
    """Stage-2/3 pipeline: yields (i_sm, e0, one_hot_label)."""
    ids, labs = list(image_ids), list(labels)

    def gen():
        order = np.random.default_rng(seed).permutation(len(ids)) if training \
            else np.arange(len(ids))
        for i in order:
            s = make_classification_sample(root, dataset, ids[i], labs[i],
                                           size, operator)
            y = np.zeros(num_classes, np.float32)
            y[s['label']] = 1.0
            yield s['i_sm'], s['e0'], y

    sig = (tf.TensorSpec((size, size, 3), tf.float32),
           tf.TensorSpec((size, size, 1), tf.float32),
           tf.TensorSpec((num_classes,), tf.float32))
    ds = tf.data.Dataset.from_generator(gen, output_signature=sig).batch(batch)
    if training and use_augmentation:
        def _aug(i, e0, y):
            i, ex = augment(i, {'e0': e0})
            return i, ex['e0'], y
        ds = ds.map(_aug, num_parallel_calls=tf.data.AUTOTUNE)
    return ds.prefetch(tf.data.AUTOTUNE)


def label_index(dataset: str) -> dict[str, int]:
    """Class name -> index, in the order declared in annee.config."""
    return {c: i for i, c in enumerate(DATASETS[dataset]['classes'])}
