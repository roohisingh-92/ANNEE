"""Network definitions.

The architecture is the one of Section 3.11 and it reproduces Table 2 exactly:

    attention gate            37 parameters          2.4 MMAC
    encoder              389,664 parameters        981.5 MMAC
    residual bottleneck 3,673,600 parameters       939.5 MMAC
    decoder             3,224,320 parameters     9,932.4 MMAC
    two 1x1 heads             66 parameters          4.2 MMAC
    ------------------------------------------------------------
    segmentation        7,287,687 parameters    11,859.7 MMAC
    classifier            457,800 parameters     1,000.4 MMAC

``scripts/count_macs.py`` recomputes both columns from the built models.
"""
from __future__ import annotations

import tensorflow as tf
from tensorflow.keras import layers, Model

from .config import (IMAGE_SIZE, ENCODER_FILTERS, BOTTLENECK_FILTERS,
                     DECODER_FILTERS, CLASSIFIER_FILTERS, CLASSIFIER_DENSE,
                     CLASSIFIER_DROPOUT, GATE_KERNEL, CLASSIFIER_INPUT_CHANNELS)


# --------------------------------------------------------------------------
# Building blocks
# --------------------------------------------------------------------------
def residual_block(x, filters: int, name: str):
    """Conv-BN-ReLU, Conv-BN, projection shortcut, ReLU (Section 3.11)."""
    shortcut = x
    if x.shape[-1] != filters:
        shortcut = layers.Conv2D(filters, 1, padding='same',
                                 name=f'{name}_proj')(x)
    y = layers.Conv2D(filters, 3, padding='same', name=f'{name}_conv1')(x)
    y = layers.BatchNormalization(name=f'{name}_bn1')(y)
    y = layers.Activation('relu', name=f'{name}_relu1')(y)
    y = layers.Conv2D(filters, 3, padding='same', name=f'{name}_conv2')(y)
    y = layers.BatchNormalization(name=f'{name}_bn2')(y)
    y = layers.Add(name=f'{name}_add')([shortcut, y])
    return layers.Activation('relu', name=f'{name}_out')(y)


def encoder_block(x, filters: int, name: str):
    """One 3x3 convolution, batch normalisation and ReLU, then 2x2 max pooling.

    One convolution per block, not two: this is what makes the encoder
    389,664 parameters, the figure Table 2 reports.
    """
    y = layers.Conv2D(filters, 3, padding='same', name=f'{name}_conv')(x)
    y = layers.BatchNormalization(name=f'{name}_bn')(y)
    skip = layers.Activation('relu', name=f'{name}_relu')(y)
    pooled = layers.MaxPooling2D(2, name=f'{name}_pool')(skip)
    return skip, pooled


def attention_gate(smoothed, edge, kernel_size: int = GATE_KERNEL):
    """First adaptive mechanism of Section 3.5.

        A(x,y) = sigma( W_a * [I_smooth(x,y), E_0(x,y)] + b_a )
        E_ad   = A (*) E_0

    A single 3x3 convolution over the four input channels: 9*4*1 + 1 = 37
    learnable parameters and 2.4 MMAC at 256 x 256, the figures quoted in
    Section 3.9. Built in the functional graph rather than wrapped in a
    custom layer, so that the MAC counter and Keras serialisation both see it.

    Returns (E_ad, A).
    """
    x = layers.Concatenate(name='gate_concat')([smoothed, edge])
    a = layers.Conv2D(1, kernel_size, padding='same', use_bias=True,
                      activation='sigmoid', name='gate_conv')(x)
    return layers.Multiply(name='gate_apply')([a, edge]), a


# --------------------------------------------------------------------------
# Segmentation network
# --------------------------------------------------------------------------
def build_segmentation_network(image_size: int = IMAGE_SIZE,
                               use_attention_gate: bool = True,
                               use_edge_channel: bool = True,
                               name: str = 'annee_segmentation') -> Model:
    """ANNEE U-Net with two sigmoid heads (Sections 3.2.6, 3.2.7, 3.11).

    Inputs
        image : (B, H, W, 3)  I_smooth, the preprocessed image
        edge  : (B, H, W, 1)  E_0, the rescaled classical edge prior

    Outputs
        e_hat : (B, H, W, 1)  boundary-probability map, forwarded to the classifier
        r_hat : (B, H, W, 1)  lesion-region probability map, source of the mask
        gate  : (B, H, W, 1)  the attention map A, kept for interpretability figures

    ``use_attention_gate=False`` is ablation variant (B), plain concatenation
    of E_0; ``use_edge_channel=False`` is variant (C), no edge input at all.
    """
    img = layers.Input((image_size, image_size, 3), name='image')
    e0 = layers.Input((image_size, image_size, 1), name='edge')

    if not use_edge_channel:
        gate_map = layers.Lambda(tf.zeros_like, name='gate_null')(e0)
        x = img
    elif use_attention_gate:
        e_ad, gate_map = attention_gate(img, e0)
        x = layers.Concatenate(name='fuse')([img, e_ad])
    else:
        gate_map = layers.Lambda(tf.ones_like, name='gate_identity')(e0)
        x = layers.Concatenate(name='fuse')([img, e0])

    skips = []
    for i, f in enumerate(ENCODER_FILTERS):
        skip, x = encoder_block(x, f, name=f'enc{i + 1}')
        skips.append(skip)

    x = residual_block(x, BOTTLENECK_FILTERS, name='bottleneck')

    for i, f in enumerate(DECODER_FILTERS):
        x = layers.Conv2DTranspose(f, 2, strides=2, padding='same',
                                   name=f'dec{i + 1}_up')(x)
        x = layers.Concatenate(name=f'dec{i + 1}_cat')([x, skips[-(i + 1)]])
        x = residual_block(x, f, name=f'dec{i + 1}_res')

    e_hat = layers.Conv2D(1, 1, activation='sigmoid', name='head_boundary')(x)
    r_hat = layers.Conv2D(1, 1, activation='sigmoid', name='head_region')(x)
    return Model([img, e0], [e_hat, r_hat, gate_map], name=name)


def build_vanilla_unet(image_size: int = IMAGE_SIZE,
                       name: str = 'vanilla_unet') -> Model:
    """Ablation variant (I) and the U-Net row of Table 10(a).

    The same 32-512 topology with no gate, no edge input and one head, which
    is what gives it 7.29 M parameters and 11.84 GMAC.
    """
    img = layers.Input((image_size, image_size, 3), name='image')
    x = img
    skips = []
    for i, f in enumerate(ENCODER_FILTERS):
        skip, x = encoder_block(x, f, name=f'enc{i + 1}')
        skips.append(skip)
    x = residual_block(x, BOTTLENECK_FILTERS, name='bottleneck')
    for i, f in enumerate(DECODER_FILTERS):
        x = layers.Conv2DTranspose(f, 2, strides=2, padding='same',
                                   name=f'dec{i + 1}_up')(x)
        x = layers.Concatenate(name=f'dec{i + 1}_cat')([x, skips[-(i + 1)]])
        x = residual_block(x, f, name=f'dec{i + 1}_res')
    r_hat = layers.Conv2D(1, 1, activation='sigmoid', name='head_region')(x)
    return Model(img, r_hat, name=name)


# --------------------------------------------------------------------------
# Classification network
# --------------------------------------------------------------------------
def build_classifier(num_classes: int, image_size: int = IMAGE_SIZE,
                     name: str = 'annee_classifier') -> Model:
    """Classifier of Section 3.11, consuming the five-channel tensor of 3.6.

    Four conv blocks (32, 64, 128, 256), global average pooling, a 256-unit
    dense layer with dropout 0.5 and a softmax output. With 8 classes this is
    457,800 parameters and 1,000.4 MMAC, the figures of Table 2.
    """
    inp = layers.Input((image_size, image_size, CLASSIFIER_INPUT_CHANNELS),
                       name='cls_input')
    x = inp
    for i, f in enumerate(CLASSIFIER_FILTERS):
        x = layers.Conv2D(f, 3, padding='same', name=f'cls{i + 1}_conv')(x)
        x = layers.BatchNormalization(name=f'cls{i + 1}_bn')(x)
        x = layers.Activation('relu', name=f'cls{i + 1}_relu')(x)
        x = layers.MaxPooling2D(2, name=f'cls{i + 1}_pool')(x)
    x = layers.GlobalAveragePooling2D(name='cls_gap')(x)
    x = layers.Dense(CLASSIFIER_DENSE, activation='relu', name='cls_dense')(x)
    x = layers.Dropout(CLASSIFIER_DROPOUT, name='cls_dropout')(x)
    out = layers.Dense(num_classes, activation='softmax', name='cls_softmax')(x)
    return Model(inp, out, name=name)


def build_models(cfg) -> tuple[Model, Model]:
    """Both networks for a run configuration (see annee.config.RunConfig)."""
    seg = build_segmentation_network(
        image_size=cfg.image_size,
        use_attention_gate=cfg.use_attention_gate,
        use_edge_channel=cfg.use_edge_channel)
    cls = build_classifier(cfg.num_classes, image_size=cfg.image_size)
    return seg, cls
