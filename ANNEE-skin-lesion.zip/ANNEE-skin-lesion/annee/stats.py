"""Significance tests and confidence intervals (Section 3.11).

Three procedures, each operating on saved per-image predictions so that every
p-value and interval in the paper is recomputable:

* McNemar's test for paired accuracy on the identical test set (Table 7,
  the ``p vs (A)`` column);
* DeLong's test for paired ROC AUC (the AUC claims of Section 4);
* bootstrap resampling of the test set, 1,000 resamples, for 95% intervals.

A note on what these can and cannot support. Every significance claim in the
paper refers to internally reproduced variants on identical test data.
Comparisons with published numbers (Table 8) are indicative only, because the
per-image predictions of those methods on our splits are not available.
"""
from __future__ import annotations

import numpy as np
from scipy import stats

from .config import BOOTSTRAP_RESAMPLES


# --------------------------------------------------------------------------
# McNemar
# --------------------------------------------------------------------------
def mcnemar(correct_a: np.ndarray, correct_b: np.ndarray,
            exact_threshold: int = 25) -> dict:
    """Paired test of accuracy between two models on the same test set.

    ``correct_a`` and ``correct_b`` are boolean arrays, one entry per test
    image. Uses the exact binomial test when the number of discordant pairs is
    small and the chi-square approximation with continuity correction
    otherwise.
    """
    a = np.asarray(correct_a, bool)
    b = np.asarray(correct_b, bool)
    if a.shape != b.shape:
        raise ValueError('the two models must be evaluated on the same images')
    n01 = int((a & ~b).sum())      # A right, B wrong
    n10 = int((~a & b).sum())      # A wrong, B right
    n = n01 + n10
    if n == 0:
        return {'n01': n01, 'n10': n10, 'statistic': 0.0, 'p_value': 1.0,
                'method': 'identical predictions'}
    if n < exact_threshold:
        p = float(stats.binomtest(n01, n, 0.5).pvalue)
        return {'n01': n01, 'n10': n10, 'statistic': float(min(n01, n10)),
                'p_value': p, 'method': 'exact binomial'}
    chi2 = (abs(n01 - n10) - 1.0) ** 2 / n
    return {'n01': n01, 'n10': n10, 'statistic': float(chi2),
            'p_value': float(stats.chi2.sf(chi2, 1)),
            'method': 'chi-square with continuity correction'}


# --------------------------------------------------------------------------
# DeLong
# --------------------------------------------------------------------------
def _midrank(x: np.ndarray) -> np.ndarray:
    order = np.argsort(x)
    sorted_x = x[order]
    n = len(x)
    ranks = np.empty(n, float)
    i = 0
    while i < n:
        j = i
        while j < n - 1 and sorted_x[j + 1] == sorted_x[i]:
            j += 1
        ranks[i:j + 1] = 0.5 * (i + j) + 1
        i = j + 1
    out = np.empty(n, float)
    out[order] = ranks
    return out


def _delong_components(scores: np.ndarray, positive: np.ndarray):
    """Structural components of the AUC for several score vectors at once."""
    pos = scores[:, positive]
    neg = scores[:, ~positive]
    m, n = pos.shape[1], neg.shape[1]
    k = scores.shape[0]
    tx = np.empty((k, m)); ty = np.empty((k, n)); tz = np.empty((k, m + n))
    for r in range(k):
        tx[r] = _midrank(pos[r])
        ty[r] = _midrank(neg[r])
        tz[r] = _midrank(scores[r])
    auc = (tz[:, :m].sum(1) / m - (m + 1) / 2.0) / n
    v01 = (tz[:, :m] - tx) / n
    v10 = 1.0 - (tz[:, m:] - ty) / m
    s01 = np.cov(v01) if k > 1 else np.array([[np.var(v01[0], ddof=1)]])
    s10 = np.cov(v10) if k > 1 else np.array([[np.var(v10[0], ddof=1)]])
    cov = np.atleast_2d(s01) / m + np.atleast_2d(s10) / n
    return auc, cov


def delong(y_true: np.ndarray, score_a: np.ndarray, score_b: np.ndarray) -> dict:
    """DeLong's paired test for two correlated ROC AUCs on the same cases."""
    y = np.asarray(y_true).astype(bool)
    scores = np.vstack([np.asarray(score_a, float), np.asarray(score_b, float)])
    order = np.argsort(-y.astype(int), kind='mergesort')
    auc, cov = _delong_components(scores[:, order], y[order])
    var = cov[0, 0] + cov[1, 1] - 2 * cov[0, 1]
    if var <= 0:
        return {'auc_a': float(auc[0]), 'auc_b': float(auc[1]),
                'z': 0.0, 'p_value': 1.0}
    z = (auc[0] - auc[1]) / np.sqrt(var)
    return {'auc_a': float(auc[0]), 'auc_b': float(auc[1]), 'z': float(z),
            'p_value': float(2 * stats.norm.sf(abs(z)))}


# --------------------------------------------------------------------------
# Bootstrap
# --------------------------------------------------------------------------
def bootstrap_ci(values: np.ndarray, statistic=np.mean,
                 resamples: int = BOOTSTRAP_RESAMPLES, alpha: float = 0.05,
                 seed: int = 0) -> dict:
    """Percentile bootstrap over the test set (1,000 resamples, Section 3.11)."""
    v = np.asarray(values, float)
    rng = np.random.default_rng(seed)
    n = len(v)
    draws = np.empty(resamples)
    for b in range(resamples):
        draws[b] = statistic(v[rng.integers(0, n, n)])
    lo, hi = np.percentile(draws, [100 * alpha / 2, 100 * (1 - alpha / 2)])
    return {'estimate': float(statistic(v)), 'ci_low': float(lo),
            'ci_high': float(hi), 'resamples': resamples}


def accuracy_ci(correct: np.ndarray, **kw) -> dict:
    """95% bootstrap interval for overall accuracy."""
    return bootstrap_ci(np.asarray(correct, float), np.mean, **kw)
