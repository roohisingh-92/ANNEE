"""Training objectives.

This module is the single source of truth for the objective of the paper.
It implements Eqs. (13), (14) and (15a)-(15c) and nothing else; no other
module defines a loss. Reviewer 2's second request was that the manuscript
give "one implementation-consistent formulation for each training stage",
and the mapping is one-to-one:

    Eq. (13)   L_edge     ->  edge_preservation_loss
    Eq. (14)   L_lesion   ->  lesion_loss
    Eq. (15a)  Stage 1    ->  UncertaintyWeights.stage1_objective
    Eq. (15b)  Stage 2    ->  classification_loss
    Eq. (15c)  Stage 3    ->  UncertaintyWeights.stage3_objective

Two points the reviewer asked to be explicit about:

* **Reduction.** Both L_edge and L_lesion are *mean*-reduced over the image
  domain Omega (|Omega| = 256 x 256 = 65,536) and then averaged over the
  mini-batch. The unnormalised sum of the first submission differed from this
  by the constant factor |Omega|.
* **The weights.** s_e and s_l are unconstrained scalars initialised at zero.
  The quantities multiplying the loss terms are the *raw* coefficients
  exp(-s_e) and exp(-s_l); no normalisation or clipping is applied during
  optimisation. The values alpha ~ 0.31 and beta ~ 0.69 quoted in the paper
  are the *normalised shares* returned by ``normalised_shares`` - reported for
  presentation only, which is why they sum to one.
"""
from __future__ import annotations

import tensorflow as tf

from .config import DICE_SMOOTH, S_INIT, LAMBDA_CLASS


# --------------------------------------------------------------------------
# Eq. (13): edge-preservation loss, annotation-free
# --------------------------------------------------------------------------
def edge_preservation_loss(e_hat: tf.Tensor, e0: tf.Tensor) -> tf.Tensor:
    """L_edge = (1/|Omega|) * sum_{(x,y) in Omega} |E_hat(x,y) - E_0(x,y)|.

    Mean absolute difference between the predicted boundary map and the
    classical prior computed from the image itself. It needs no expert mask,
    which is what makes the cross-dataset transfer of Section 3.11.1 possible.
    Returned per sample; callers average over the batch.
    """
    return tf.reduce_mean(tf.abs(e_hat - e0), axis=[1, 2, 3])


# --------------------------------------------------------------------------
# Eq. (14): complete lesion loss, region + boundary
# --------------------------------------------------------------------------
def soft_dice(r_hat: tf.Tensor, m_true: tf.Tensor,
              smooth: float = DICE_SMOOTH) -> tf.Tensor:
    """Soft Dice on probabilities, no thresholding, smoothing constant 1."""
    axes = [1, 2, 3]
    inter = tf.reduce_sum(r_hat * m_true, axis=axes)
    denom = tf.reduce_sum(r_hat, axis=axes) + tf.reduce_sum(m_true, axis=axes)
    return (2.0 * inter + smooth) / (denom + smooth)


def binary_cross_entropy(r_hat: tf.Tensor, m_true: tf.Tensor) -> tf.Tensor:
    """Pixel-wise BCE under the same mean reduction as Eq. (13)."""
    r = tf.clip_by_value(r_hat, 1e-7, 1.0 - 1e-7)
    bce = -(m_true * tf.math.log(r) + (1.0 - m_true) * tf.math.log(1.0 - r))
    return tf.reduce_mean(bce, axis=[1, 2, 3])


def lesion_loss(r_hat: tf.Tensor, e_hat: tf.Tensor,
                m_true: tf.Tensor, e_true: tf.Tensor) -> tf.Tensor:
    """L_lesion = [1 - Dice(R_hat, M_true)] + BCE(R_hat, M_true)
                  + (1/|Omega|) sum |E_hat - E_true|.

    Defined only where pixel-level supervision exists, that is on ISIC 2018
    Task 1. The region component - soft Dice plus BCE on the region head - is
    the part that the first version of the manuscript omitted from the written
    objective although it was always present in the code.
    """
    region = (1.0 - soft_dice(r_hat, m_true)) + binary_cross_entropy(r_hat, m_true)
    boundary = tf.reduce_mean(tf.abs(e_hat - e_true), axis=[1, 2, 3])
    return region + boundary


# --------------------------------------------------------------------------
# Eq. (15b) / Section 3.8, Eq. (23): class-weighted cross-entropy
# --------------------------------------------------------------------------
def classification_loss(y_true: tf.Tensor, y_prob: tf.Tensor,
                        class_weights: tf.Tensor | None = None) -> tf.Tensor:
    """L_class = - sum_i w_i y_i log(y_hat_i)   (Eq. 23).

    ``class_weights`` are the inverse-frequency weights w_k = N / (K n_k) of
    Section 3.12. Passing None recovers the unweighted cross-entropy.
    """
    p = tf.clip_by_value(y_prob, 1e-7, 1.0)
    terms = y_true * tf.math.log(p)
    if class_weights is not None:
        terms = terms * tf.reshape(class_weights, [1, -1])
    return -tf.reduce_sum(terms, axis=-1)


def inverse_frequency_weights(counts) -> tf.Tensor:
    """w_k = N / (K * n_k), the balanced weighting of Section 3.12.

    Satisfies sum_k n_k w_k = N, which ``tests/test_losses.py`` checks.
    """
    counts = tf.cast(tf.convert_to_tensor(counts), tf.float32)
    n = tf.reduce_sum(counts)
    k = tf.cast(tf.size(counts), tf.float32)
    return n / (k * counts)


# --------------------------------------------------------------------------
# Eqs. (15a) and (15c): the stage objectives
# --------------------------------------------------------------------------
class UncertaintyWeights(tf.Module):
    """Homoscedastic-uncertainty weighting of Kendall et al. [29].

    Holds the two learnable log-variances s_e and s_l. They are unconstrained
    scalars, initialised at zero, and are updated by the same optimiser as the
    network weights. Nothing normalises or clips them.

    Set ``fixed=(alpha, beta)`` for the fixed-weight variants (J)-(L) of
    Table 7: the objective then becomes alpha*L_edge + beta*L_lesion with no
    s_e, s_l terms at all, every other element of the protocol unchanged.
    """

    def __init__(self, fixed: tuple[float, float] | None = None,
                 s_init: float = S_INIT, name: str = 'uncertainty_weights'):
        super().__init__(name=name)
        self.fixed = fixed
        if fixed is None:
            self.s_e = tf.Variable(s_init, dtype=tf.float32, name='s_e')
            self.s_l = tf.Variable(s_init, dtype=tf.float32, name='s_l')
        else:
            self.s_e = None
            self.s_l = None

    # -- raw coefficients ---------------------------------------------------
    @property
    def alpha_raw(self) -> tf.Tensor:
        """exp(-s_e): the coefficient that actually multiplies L_edge."""
        if self.fixed is not None:
            return tf.constant(self.fixed[0], tf.float32)
        return tf.exp(-self.s_e)

    @property
    def beta_raw(self) -> tf.Tensor:
        """exp(-s_l): the coefficient that actually multiplies L_lesion."""
        if self.fixed is not None:
            return tf.constant(self.fixed[1], tf.float32)
        return tf.exp(-self.s_l)

    # -- reported shares ----------------------------------------------------
    def normalised_shares(self) -> tuple[tf.Tensor, tf.Tensor]:
        """alpha_norm = exp(-s_e) / (exp(-s_e) + exp(-s_l)),  beta_norm = 1 - alpha_norm.

        These are the numbers quoted as alpha ~ 0.31 and beta ~ 0.69 in
        Sections 3.5 and 3.11.1. They are reported for presentation so that the
        relative emphasis can be compared with the fixed-weight variants, and
        they are *not* the coefficients used in the optimisation.
        """
        a, b = self.alpha_raw, self.beta_raw
        total = a + b
        a_n = a / total
        return a_n, 1.0 - a_n

    @property
    def trainable_variables(self):
        return () if self.fixed is not None else (self.s_e, self.s_l)

    # -- objectives ---------------------------------------------------------
    def stage1_objective(self, l_edge: tf.Tensor, l_lesion: tf.Tensor) -> tf.Tensor:
        """Eq. (15a): L1 = e^(-s_e) L_edge + s_e + e^(-s_l) L_lesion + s_l.

        The additive s_e and s_l are the regularisers that prevent the trivial
        solution in which both coefficients vanish. Stage 1 is the only stage
        in which L_lesion, and therefore beta, is active.
        """
        if self.fixed is not None:
            return self.fixed[0] * l_edge + self.fixed[1] * l_lesion
        return (tf.exp(-self.s_e) * l_edge + self.s_e +
                tf.exp(-self.s_l) * l_lesion + self.s_l)

    def stage3_objective(self, l_edge: tf.Tensor, l_class: tf.Tensor,
                         lam: float = LAMBDA_CLASS) -> tf.Tensor:
        """Eq. (15c): L3 = e^(-s_e) L_edge + s_e + lambda L_class.

        E_true does not exist on the classification archives, so L_lesion is
        removed and the only segmentation-side term that survives is the
        annotation-free L_edge.
        """
        if self.fixed is not None:
            return self.fixed[0] * l_edge + lam * l_class
        return tf.exp(-self.s_e) * l_edge + self.s_e + lam * l_class


def stage2_objective(l_class: tf.Tensor) -> tf.Tensor:
    """Eq. (15b): L2 = L_class. The segmentation network is frozen."""
    return l_class
