"""The three-stage training protocol of Section 3.11.1 and Fig. 1(b).

    Stage 1  segmentation pre-training on ISIC 2018 Task 1, Eq. (15a).
             The only stage in which L_lesion, and therefore beta, is active.
             Saves  stage1.weights.h5.

    Stage 2  classifier pre-training on a classification archive, Eq. (15b).
             Theta_seg is transferred and frozen; only the classifier trains.
             Saves  stage2_<archive>.weights.h5.

    Stage 3  joint fine-tuning on the same archive, Eq. (15c). Encoder frozen;
             decoder, gate and classifier updated. L_lesion is inactive because
             E_true does not exist here. Run separately for each archive, so
             the protocol yields one Stage-3 checkpoint per archive.
             Saves  stage3_<archive>.weights.h5.

Why the checkpoints are named and saved separately: Reviewer 2 asked which
training-stage checkpoint each Table 9 row was evaluated at. Here the answer is
a file name, not a recollection, and ``scripts/predict_segmentation.py`` takes
``--stage`` explicitly and records it in the prediction manifest.

The training path never calls the morphological block. Otsu thresholding,
binarisation, morphology and connected-component selection are
non-differentiable and live in :mod:`annee.postprocess`, which is imported by
the inference scripts only.
"""
from __future__ import annotations

import json
import time
from dataclasses import asdict
from pathlib import Path

import numpy as np
import tensorflow as tf

from .config import (LR_STAGE12, LR_STAGE3, STAGE3_EPOCHS, STAGE3_PATIENCE,
                     MAX_EPOCHS, EARLY_STOPPING_PATIENCE, LR_PLATEAU_FACTOR,
                     LR_PLATEAU_PATIENCE, ADAM_BETA_1, ADAM_BETA_2,
                     LAMBDA_CLASS)
from .losses import (edge_preservation_loss, lesion_loss, classification_loss,
                     UncertaintyWeights, inverse_frequency_weights)
from .postprocess import classifier_input_soft


# --------------------------------------------------------------------------
# Logging
# --------------------------------------------------------------------------
class EpochLog:
    """Per-epoch record behind Table 6, Fig. 3 and the released weight traces.

    Besides the usual losses and accuracies it stores s_e, s_l, the raw
    coefficients exp(-s_e), exp(-s_l) and the two normalised shares, so that
    the claim 'alpha_norm ~ 0.31 and beta_norm ~ 0.69 at convergence' can be
    checked against the trajectory rather than taken on trust.
    """

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.rows: list[dict] = []

    def append(self, **row):
        row['wall_time'] = time.time()
        self.rows.append(row)
        self.path.write_text(json.dumps(self.rows, indent=2), encoding='utf-8')

    def to_csv(self, path: str | Path | None = None):
        import pandas as pd
        p = Path(path or self.path.with_suffix('.csv'))
        pd.DataFrame(self.rows).to_csv(p, index=False)
        return p


def _weight_trace(weights: UncertaintyWeights) -> dict:
    if weights.fixed is not None:
        return {'s_e': None, 's_l': None,
                'alpha_raw': float(weights.fixed[0]),
                'beta_raw': float(weights.fixed[1]),
                'alpha_norm': float(weights.fixed[0]),
                'beta_norm': float(weights.fixed[1])}
    a_n, b_n = weights.normalised_shares()
    return {'s_e': float(weights.s_e.numpy()), 's_l': float(weights.s_l.numpy()),
            'alpha_raw': float(weights.alpha_raw.numpy()),
            'beta_raw': float(weights.beta_raw.numpy()),
            'alpha_norm': float(a_n.numpy()), 'beta_norm': float(b_n.numpy())}


def _optimizer(lr: float) -> tf.keras.optimizers.Optimizer:
    return tf.keras.optimizers.Adam(learning_rate=lr, beta_1=ADAM_BETA_1,
                                    beta_2=ADAM_BETA_2)


# --------------------------------------------------------------------------
# Stage 1
# --------------------------------------------------------------------------
def train_stage1(seg_model, train_ds, val_ds, out_dir, cfg,
                 epochs: int = MAX_EPOCHS, lr: float = LR_STAGE12,
                 patience: int = EARLY_STOPPING_PATIENCE):
    """Segmentation pre-training under Eq. (15a)."""
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    weights = UncertaintyWeights(fixed=cfg.fixed_weights)
    opt = _optimizer(lr)
    log = EpochLog(out / 'stage1_log.json')
    variables = list(seg_model.trainable_variables) + list(weights.trainable_variables)

    @tf.function
    def step(i_sm, e0, m_true, e_true, training=True):
        with tf.GradientTape() as tape:
            e_hat, r_hat, _ = seg_model([i_sm, e0], training=training)
            l_edge = tf.reduce_mean(edge_preservation_loss(e_hat, e0))
            l_lesion = tf.reduce_mean(lesion_loss(r_hat, e_hat, m_true, e_true))
            if not cfg.use_edge_loss:                 # variant (D): alpha = 0
                l_edge = tf.zeros_like(l_edge)
            total = weights.stage1_objective(l_edge, l_lesion)
        if training:
            grads = tape.gradient(total, variables)
            opt.apply_gradients([(g, v) for g, v in zip(grads, variables)
                                 if g is not None])
        return total, l_edge, l_lesion

    best, bad, best_epoch = np.inf, 0, -1
    current_lr = lr
    for epoch in range(epochs):
        tr = [np.array([float(x) for x in step(*b)]) for b in train_ds]
        va = [np.array([float(x) for x in step(*b, training=False)]) for b in val_ds]
        tr_m = np.mean(tr, 0) if tr else np.zeros(3)
        va_m = np.mean(va, 0) if va else np.zeros(3)
        log.append(stage=1, epoch=epoch, lr=float(current_lr),
                   train_total=tr_m[0], train_edge=tr_m[1], train_lesion=tr_m[2],
                   val_total=va_m[0], val_edge=va_m[1], val_lesion=va_m[2],
                   **_weight_trace(weights))
        if va_m[0] < best - 1e-6:
            best, bad, best_epoch = va_m[0], 0, epoch
            seg_model.save_weights(out / 'stage1.weights.h5')
            (out / 'stage1_weights_meta.json').write_text(
                json.dumps({'epoch': epoch, 'val_total': float(best),
                            **_weight_trace(weights)}, indent=2), encoding='utf-8')
        else:
            bad += 1
            if bad == LR_PLATEAU_PATIENCE:            # factor-of-10 reduction
                current_lr *= LR_PLATEAU_FACTOR
                opt.learning_rate.assign(current_lr)
            if bad >= patience:
                break
    return {'best_epoch': best_epoch, 'best_val': float(best),
            'checkpoint': str(out / 'stage1.weights.h5'),
            'weights': _weight_trace(weights)}


# --------------------------------------------------------------------------
# Stage 2
# --------------------------------------------------------------------------
def train_stage2(seg_model, cls_model, train_ds, val_ds, out_dir, cfg,
                 class_counts=None, epochs: int = MAX_EPOCHS,
                 lr: float = LR_STAGE12,
                 patience: int = EARLY_STOPPING_PATIENCE):
    """Classifier pre-training under Eq. (15b); Theta_seg frozen."""
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    seg_model.trainable = False
    w = inverse_frequency_weights(class_counts) if class_counts is not None else None
    opt = _optimizer(lr)
    log = EpochLog(out / f'stage2_{cfg.dataset}_log.json')

    @tf.function
    def step(i_sm, e0, y, training=True):
        e_hat, r_hat, _ = seg_model([i_sm, e0], training=False)
        x = classifier_input_soft(i_sm, r_hat, e_hat)
        with tf.GradientTape() as tape:
            p = cls_model(x, training=training)
            loss = tf.reduce_mean(classification_loss(y, p, w))
        if training:
            grads = tape.gradient(loss, cls_model.trainable_variables)
            opt.apply_gradients(zip(grads, cls_model.trainable_variables))
        acc = tf.reduce_mean(tf.cast(
            tf.equal(tf.argmax(p, -1), tf.argmax(y, -1)), tf.float32))
        return loss, acc

    best, bad, best_epoch = np.inf, 0, -1
    current_lr = lr
    for epoch in range(epochs):
        tr = [np.array([float(x) for x in step(*b)]) for b in train_ds]
        va = [np.array([float(x) for x in step(*b, training=False)]) for b in val_ds]
        tr_m = np.mean(tr, 0) if tr else np.zeros(2)
        va_m = np.mean(va, 0) if va else np.zeros(2)
        log.append(stage=2, epoch=epoch, lr=float(current_lr),
                   train_loss=tr_m[0], train_accuracy=tr_m[1],
                   val_loss=va_m[0], val_accuracy=va_m[1])
        if va_m[0] < best - 1e-6:
            best, bad, best_epoch = va_m[0], 0, epoch
            cls_model.save_weights(out / f'stage2_{cfg.dataset}.weights.h5')
        else:
            bad += 1
            if bad == LR_PLATEAU_PATIENCE:
                current_lr *= LR_PLATEAU_FACTOR
                opt.learning_rate.assign(current_lr)
            if bad >= patience:
                break
    seg_model.trainable = True
    return {'best_epoch': best_epoch, 'best_val': float(best),
            'checkpoint': str(out / f'stage2_{cfg.dataset}.weights.h5')}


# --------------------------------------------------------------------------
# Stage 3
# --------------------------------------------------------------------------
def freeze_encoder(seg_model) -> list[str]:
    """Freeze the encoder; the decoder, gate and heads stay trainable."""
    frozen = []
    for layer in seg_model.layers:
        if layer.name.startswith('enc'):
            layer.trainable = False
            frozen.append(layer.name)
    return frozen


def train_stage3(seg_model, cls_model, train_ds, val_ds, out_dir, cfg,
                 class_counts=None, epochs: int = STAGE3_EPOCHS,
                 lr: float = LR_STAGE3, patience: int = STAGE3_PATIENCE,
                 lam: float = LAMBDA_CLASS):
    """Joint fine-tuning under Eq. (15c) on one classification archive.

    L_lesion is inactive throughout: E_true does not exist for these datasets.
    The only segmentation-side term is the annotation-free L_edge, whose
    weight continues to be adapted through s_e.
    """
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    weights = UncertaintyWeights(fixed=cfg.fixed_weights)
    frozen = freeze_encoder(seg_model)
    w = inverse_frequency_weights(class_counts) if class_counts is not None else None
    opt = _optimizer(lr)
    log = EpochLog(out / f'stage3_{cfg.dataset}_log.json')
    variables = (list(seg_model.trainable_variables) +
                 list(cls_model.trainable_variables) +
                 list(weights.trainable_variables))

    @tf.function
    def step(i_sm, e0, y, training=True):
        with tf.GradientTape() as tape:
            e_hat, r_hat, _ = seg_model([i_sm, e0], training=training)
            # training path: soft mask and contour-free confidence, so that
            # dL_class/dTheta_seg is well defined (Section 3.6)
            x = classifier_input_soft(i_sm, r_hat, e_hat)
            p = cls_model(x, training=training)
            l_class = tf.reduce_mean(classification_loss(y, p, w))
            l_edge = tf.reduce_mean(edge_preservation_loss(e_hat, e0))
            if not cfg.use_edge_loss:
                l_edge = tf.zeros_like(l_edge)
            total = weights.stage3_objective(l_edge, l_class, lam)
        if training:
            grads = tape.gradient(total, variables)
            opt.apply_gradients([(g, v) for g, v in zip(grads, variables)
                                 if g is not None])
        acc = tf.reduce_mean(tf.cast(
            tf.equal(tf.argmax(p, -1), tf.argmax(y, -1)), tf.float32))
        return total, l_edge, l_class, acc

    best, bad, best_epoch = np.inf, 0, -1
    for epoch in range(epochs):
        tr = [np.array([float(x) for x in step(*b)]) for b in train_ds]
        va = [np.array([float(x) for x in step(*b, training=False)]) for b in val_ds]
        tr_m = np.mean(tr, 0) if tr else np.zeros(4)
        va_m = np.mean(va, 0) if va else np.zeros(4)
        log.append(stage=3, epoch=epoch, lr=float(lr), lam=float(lam),
                   train_total=tr_m[0], train_edge=tr_m[1],
                   train_class=tr_m[2], train_accuracy=tr_m[3],
                   val_total=va_m[0], val_edge=va_m[1],
                   val_class=va_m[2], val_accuracy=va_m[3],
                   **_weight_trace(weights))
        if va_m[2] < best - 1e-6:                     # early stop on val L_class
            best, bad, best_epoch = va_m[2], 0, epoch
            seg_model.save_weights(out / f'stage3_{cfg.dataset}_seg.weights.h5')
            cls_model.save_weights(out / f'stage3_{cfg.dataset}_cls.weights.h5')
            (out / f'stage3_{cfg.dataset}_meta.json').write_text(json.dumps({
                'epoch': epoch, 'val_class_loss': float(best),
                'frozen_layers': frozen, 'lambda': float(lam),
                'archive': cfg.dataset, **_weight_trace(weights)},
                indent=2), encoding='utf-8')
        else:
            bad += 1
            if bad >= patience:
                break
    return {'best_epoch': best_epoch, 'best_val_class': float(best),
            'archive': cfg.dataset,
            'seg_checkpoint': str(out / f'stage3_{cfg.dataset}_seg.weights.h5'),
            'cls_checkpoint': str(out / f'stage3_{cfg.dataset}_cls.weights.h5'),
            'weights': _weight_trace(weights)}


def write_run_manifest(out_dir, cfg, results: dict):
    """Record what was run, so a checkpoint is never ambiguous later."""
    p = Path(out_dir) / 'run_manifest.json'
    p.write_text(json.dumps({'config': asdict(cfg), 'results': results},
                            indent=2, sort_keys=True, default=str),
                 encoding='utf-8')
    return p
