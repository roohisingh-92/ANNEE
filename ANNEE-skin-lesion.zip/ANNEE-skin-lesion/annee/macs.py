"""The single multiply-accumulate counter used for Table 2 and Table 10.

Reviewer 2 asked that the MAC counting convention be verified consistently
across the reported models. There is therefore exactly one counter, it is
applied to every entry, and the convention it implements is the one stated in
Section 4.2 of the manuscript:

* one MAC is one multiply-accumulate, equivalent to two floating-point
  operations;
* convolution, transposed-convolution, linear ("dense") and
  attention-projection layers are counted;
* batch normalisation, activations, pooling, interpolation and element-wise
  operations are **not** counted;
* batch-normalisation parameters are counted within the preceding
  convolution, i.e. they appear in the parameter column but contribute no
  MACs;
* every figure is for a single 256 x 256 RGB image in inference mode, batch
  size 1.

Formulae (Section 3.9):

    convolution           C_l = H_out * W_out * k^2 * C_in * C_out
    transposed conv s=2   C_l = H_out * W_out * k^2 * C_in * C_out
    dense                 C_l = C_in * C_out

Baseline figures in Table 10 are produced by running this same counter over
the baseline models (``annee/baselines.py``), not copied from the original
papers.
"""
from __future__ import annotations

import numpy as np
import tensorflow as tf
from tensorflow.keras import layers

COUNTED = (layers.Conv2D, layers.Conv2DTranspose, layers.Dense,
           layers.SeparableConv2D, layers.DepthwiseConv2D)


def _layer_macs(layer) -> int:
    """MACs for one layer under the convention above; 0 if not counted."""
    if isinstance(layer, layers.Dense):
        w = layer.get_weights()
        if not w:
            return 0
        c_in, c_out = w[0].shape
        # A Dense layer applied to a rank-4 tensor is a 1x1 convolution: it
        # runs once per spatial position. ConvNeXt's pointwise layers are
        # built this way, so ignoring the spatial extent undercounts them by
        # H*W.
        out = layer.output.shape
        positions = 1
        for d in out[1:-1]:
            positions *= int(d)
        return positions * int(c_in) * int(c_out)

    if isinstance(layer, layers.DepthwiseConv2D):
        out = layer.output.shape
        kh, kw = layer.kernel_size
        h, w_, c = int(out[1]), int(out[2]), int(out[3])
        return h * w_ * kh * kw * c

    if isinstance(layer, layers.SeparableConv2D):
        out = layer.output.shape
        kh, kw = layer.kernel_size
        h, w_, c_out = int(out[1]), int(out[2]), int(out[3])
        c_in = int(layer.input.shape[-1])
        return h * w_ * (kh * kw * c_in + c_in * c_out)

    if isinstance(layer, (layers.Conv2D, layers.Conv2DTranspose)):
        out = layer.output.shape
        kh, kw = layer.kernel_size
        h, w_, c_out = int(out[1]), int(out[2]), int(out[3])
        c_in = int(layer.input.shape[-1])
        # Grouped convolutions, including the depthwise 7x7 that Keras's
        # ConvNeXt implements as Conv2D(groups=dim). Ignoring `groups` would
        # overcount such a layer by a factor of `groups`.
        groups = int(getattr(layer, 'groups', 1) or 1)
        return h * w_ * kh * kw * c_in * c_out // groups

    return 0


def _walk(model):
    """Yield every leaf layer, descending into nested models."""
    for layer in model.layers:
        if isinstance(layer, tf.keras.Model):
            yield from _walk(layer)
        else:
            yield layer


def _trainable_params(layer) -> int:
    return int(sum(np.prod(w.shape) for w in layer.trainable_weights))


def count_model(model, group_fn=None) -> dict:
    """Parameters and MACs for a built Keras model.

    The parameter column counts **trainable** parameters, which is the
    convention of Table 2: batch-normalisation scale and offset are included
    (they are counted within the preceding convolution's group), while the
    non-trainable moving mean and variance are not.

    ``group_fn(layer_name) -> str`` assigns each layer to a reporting group,
    which is how the stage rows of Table 2 are produced.
    """
    rows = []
    for layer in _walk(model):
        rows.append({
            'name': layer.name,
            'type': type(layer).__name__,
            'macs': _layer_macs(layer) if isinstance(layer, COUNTED) else 0,
            'params': _trainable_params(layer),
        })
    total_macs = sum(r['macs'] for r in rows)
    trainable = sum(r['params'] for r in rows)
    out = {'layers': rows,
           'total_macs': int(total_macs),
           'total_mmac': total_macs / 1e6,
           'total_gmac': total_macs / 1e9,
           'total_params': trainable,
           'total_params_m': trainable / 1e6,
           'all_params': int(model.count_params()),
           'gflops': 2.0 * total_macs / 1e9}
    if group_fn is not None:
        groups: dict[str, dict] = {}
        for r in rows:
            g = group_fn(r['name'])
            b = groups.setdefault(g, {'macs': 0, 'params': 0})
            b['macs'] += r['macs']
            b['params'] += r['params']
        for g, b in groups.items():
            b['mmac'] = b['macs'] / 1e6
            b['pct_macs'] = 100.0 * b['macs'] / max(1, total_macs)
        out['groups'] = {g: b for g, b in groups.items()
                         if b['params'] or b['macs']}
    return out


def annee_group(name: str) -> str:
    """Grouping that reproduces the stage rows of Table 2."""
    if name.startswith('gate') or 'attention' in name:
        return 'attention gate'
    if name.startswith('enc'):
        return 'encoder'
    if name.startswith('bottleneck'):
        return 'residual bottleneck'
    if name.startswith('dec'):
        return 'decoder'
    if name.startswith('head'):
        return 'output heads'
    if name.startswith('cls'):
        return 'classifier'
    return 'other'


# --------------------------------------------------------------------------
# Classical stages, listed in Table 2 for reference and excluded from totals
# --------------------------------------------------------------------------
def classical_stage_macs(size: int = 256, sigma: float = 1.0,
                         radius: int = 5) -> dict[str, int]:
    """O(N) costs of the non-learnable stages (Section 3.9).

    Resizing, normalisation and separable Gaussian smoothing are O(N) with
    small constants; Sobel filtering costs 2*9*N MACs; morphological closing
    and opening with a disk of radius r cost O(N*r^2); connected-component
    labelling is O(N). These are listed for reference and excluded from the
    pipeline totals.
    """
    n = size * size
    k = int(4.0 * sigma + 0.5) * 2 + 1
    return {
        'resize_bilinear': 4 * n,
        'minmax_normalisation': n,
        'gaussian_separable': 2 * k * n * 3,
        'sobel_on_luma': 2 * 9 * n,
        'morphology_close_open': 2 * n * (2 * radius + 1) ** 2,
        'connected_components': n,
    }
