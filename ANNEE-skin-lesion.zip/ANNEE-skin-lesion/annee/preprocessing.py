"""Preprocessing and supervision-target construction.

Implements Sections 3.2.2-3.2.5, 3.2.7 and the clarifications of Section 3.12.
Every function exists twice: a TensorFlow version used inside the training
graph and a NumPy reference used for dataset preparation and for the tests.
``tests/test_preprocessing.py`` asserts that the two agree.

Pipeline, in the order the manuscript applies it:

    I  --resize-->  I_res  --min-max-->  I_norm  --gauss-->  I_sm
                                                              |
                                              luma (BT.601) --+--> Sobel --> E_0
"""
from __future__ import annotations

import numpy as np
import tensorflow as tf
from scipy import ndimage

from .config import (IMAGE_SIZE, GAUSSIAN_SIGMA, BT601, BOUNDARY_RADIUS_RHO)

# Sobel kernels of Section 3.2.5
SOBEL_X = np.array([[-1., 0., 1.], [-2., 0., 2.], [-1., 0., 1.]], np.float32)
SOBEL_Y = np.array([[-1., -2., -1.], [0., 0., 0.], [1., 2., 1.]], np.float32)

_EPS = 1e-8


# ==========================================================================
# NumPy reference implementation
# ==========================================================================
def np_resize_image(image: np.ndarray, size: int = IMAGE_SIZE) -> np.ndarray:
    """Bilinear resize with anti-aliasing (Section 3.12, 'Interpolation')."""
    from skimage.transform import resize
    return resize(image.astype(np.float32), (size, size),
                  order=1, mode='reflect', anti_aliasing=True,
                  preserve_range=True).astype(np.float32)


def np_resize_mask(mask: np.ndarray, size: int = IMAGE_SIZE) -> np.ndarray:
    """Nearest-neighbour resize so the mask stays binary (Section 3.12)."""
    from skimage.transform import resize
    out = resize(mask.astype(np.float32), (size, size), order=0,
                 mode='constant', anti_aliasing=False, preserve_range=True)
    return (out > 0.5).astype(np.float32)


def np_minmax(image: np.ndarray) -> np.ndarray:
    """Eq. (3): per-image min-max normalisation to [0, 1]."""
    lo, hi = float(image.min()), float(image.max())
    return (image - lo) / (hi - lo + _EPS)


def np_gaussian(image: np.ndarray, sigma: float = GAUSSIAN_SIGMA) -> np.ndarray:
    """Eq. (5)/(6): separable Gaussian smoothing, applied per channel."""
    if image.ndim == 2:
        return ndimage.gaussian_filter(image, sigma=sigma, mode='reflect')
    return np.stack([ndimage.gaussian_filter(image[..., c], sigma=sigma,
                                             mode='reflect')
                     for c in range(image.shape[-1])], axis=-1)


def np_luma(image: np.ndarray) -> np.ndarray:
    """Section 3.12: Y = 0.299R + 0.587G + 0.114B, a single channel."""
    if image.ndim == 2:
        return image
    w = np.asarray(BT601, np.float32)
    return (image[..., :3] * w).sum(-1)


def np_sobel_magnitude(gray: np.ndarray) -> np.ndarray:
    """Eq. (7): gradient magnitude of the luma channel."""
    gx = ndimage.convolve(gray, SOBEL_X, mode='reflect')
    gy = ndimage.convolve(gray, SOBEL_Y, mode='reflect')
    return np.sqrt(gx ** 2 + gy ** 2)


def np_canny(gray: np.ndarray) -> np.ndarray:
    """Ablation variant (E): Canny in place of Sobel (Section 4, Table 7)."""
    from skimage.feature import canny
    return canny(gray.astype(np.float64), sigma=1.0).astype(np.float32)


def np_initial_edge_map(smoothed: np.ndarray, operator: str = 'sobel') -> np.ndarray:
    """E_0: edge response of the luma channel, rescaled by its per-image maximum.

    Section 3.12: 'Sobel is applied to a single channel, not per colour
    channel ... and E_0 is rescaled to [0,1] by its per-image maximum before
    entering the gate.'
    """
    gray = np_luma(smoothed)
    e0 = np_canny(gray) if operator == 'canny' else np_sobel_magnitude(gray)
    return (e0 / (float(e0.max()) + _EPS)).astype(np.float32)


def np_preprocess(image: np.ndarray, size: int = IMAGE_SIZE,
                  sigma: float = GAUSSIAN_SIGMA,
                  operator: str = 'sobel') -> tuple[np.ndarray, np.ndarray]:
    """Full forward preprocessing. Returns (I_sm, E_0)."""
    i_res = np_resize_image(image, size)
    i_norm = np_minmax(i_res)
    i_sm = np_gaussian(i_norm, sigma)
    return i_sm.astype(np.float32), np_initial_edge_map(i_sm, operator)


def np_boundary_target(mask: np.ndarray,
                       rho: int = BOUNDARY_RADIUS_RHO) -> np.ndarray:
    """E_true of Section 3.2.7: symmetric morphological gradient of M_true.

        E_true = (M_true (+) B_rho) - (M_true (-) B_rho)

    with B_rho a *square* structuring element of radius rho (8-connectivity).
    The resulting band has thickness t = 2*rho px; rho = 1 gives t = 2 px.
    Computed after resizing, so t is defined at the working resolution.
    """
    m = (mask > 0.5).astype(np.float32)
    se = np.ones((2 * rho + 1, 2 * rho + 1), bool)
    dil = ndimage.binary_dilation(m > 0.5, structure=se)
    ero = ndimage.binary_erosion(m > 0.5, structure=se)
    return (dil.astype(np.float32) - ero.astype(np.float32)).astype(np.float32)


# ==========================================================================
# TensorFlow implementation (used inside the training graph)
# ==========================================================================
def _gaussian_kernel1d(sigma: float) -> tf.Tensor:
    radius = int(4.0 * sigma + 0.5)
    x = tf.range(-radius, radius + 1, dtype=tf.float32)
    k = tf.exp(-0.5 * tf.square(x / sigma))
    return k / tf.reduce_sum(k)


def tf_gaussian(images: tf.Tensor, sigma: float = GAUSSIAN_SIGMA) -> tf.Tensor:
    """Separable Gaussian blur, reflect padding, applied per channel."""
    k = _gaussian_kernel1d(sigma)
    r = (tf.shape(k)[0] - 1) // 2
    c = images.shape[-1]
    kx = tf.reshape(k, [1, -1, 1, 1]) * tf.ones([1, 1, c, 1])
    ky = tf.reshape(k, [-1, 1, 1, 1]) * tf.ones([1, 1, c, 1])
    pad = [[0, 0], [0, 0], [r, r], [0, 0]]
    x = tf.pad(images, pad, mode='REFLECT')
    x = tf.nn.depthwise_conv2d(x, kx, [1, 1, 1, 1], 'VALID')
    x = tf.pad(x, [[0, 0], [r, r], [0, 0], [0, 0]], mode='REFLECT')
    return tf.nn.depthwise_conv2d(x, ky, [1, 1, 1, 1], 'VALID')


def tf_minmax(images: tf.Tensor) -> tf.Tensor:
    lo = tf.reduce_min(images, axis=[1, 2, 3], keepdims=True)
    hi = tf.reduce_max(images, axis=[1, 2, 3], keepdims=True)
    return (images - lo) / (hi - lo + _EPS)


def tf_luma(images: tf.Tensor) -> tf.Tensor:
    w = tf.constant(BT601, tf.float32)
    return tf.reduce_sum(images[..., :3] * w, axis=-1, keepdims=True)


def tf_sobel_magnitude(gray: tf.Tensor) -> tf.Tensor:
    kx = tf.reshape(tf.constant(SOBEL_X), [3, 3, 1, 1])
    ky = tf.reshape(tf.constant(SOBEL_Y), [3, 3, 1, 1])
    g = tf.pad(gray, [[0, 0], [1, 1], [1, 1], [0, 0]], mode='REFLECT')
    gx = tf.nn.conv2d(g, kx, [1, 1, 1, 1], 'VALID')
    gy = tf.nn.conv2d(g, ky, [1, 1, 1, 1], 'VALID')
    return tf.sqrt(tf.square(gx) + tf.square(gy) + _EPS)


def tf_initial_edge_map(smoothed: tf.Tensor) -> tf.Tensor:
    e0 = tf_sobel_magnitude(tf_luma(smoothed))
    mx = tf.reduce_max(e0, axis=[1, 2, 3], keepdims=True)
    return e0 / (mx + _EPS)


def tf_preprocess(images: tf.Tensor, size: int = IMAGE_SIZE,
                  sigma: float = GAUSSIAN_SIGMA) -> tuple[tf.Tensor, tf.Tensor]:
    """Batched forward preprocessing inside the graph. Returns (I_sm, E_0)."""
    x = tf.image.resize(images, (size, size), method='bilinear', antialias=True)
    x = tf_minmax(x)
    x = tf_gaussian(x, sigma)
    return x, tf_initial_edge_map(x)
