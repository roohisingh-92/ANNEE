"""Partitioning and cross-dataset leakage control.

This module answers Reviewer 2's first and third requests. Section 3.11.1 of
the revised manuscript states two rules; both are implemented here, and
:func:`verify_leakage` reproduces the check the manuscript reports, against
the realised split assignments rather than the intended protocol.

    Rule (i)   A lesion in the ISIC 2018 Task 1 **training** split is assigned,
               with all of its acquisitions, to the classification *training*
               partition. No Stage-1 training image can then appear in a
               classification validation or test split.

    Rule (ii)  A lesion in the ISIC 2018 Task 1 **validation or test** split is
               removed from the classification archive altogether, before
               partitioning. It therefore enters no training stage: it is
               absent from Stage 2 and Stage 3 and cannot influence the
               checkpoint at which the Table 9 metrics are computed.

Rule (ii) is the one that matters for the Stage-3 checkpoint, because Stage 3
updates the segmentation decoder while training on a classification archive.

The counts the manuscript quotes (matched lesions, forced-to-train lesions,
excluded lesions and the resulting pool sizes) are *outputs* of this module.
Run ``scripts/make_splits.py`` on the real archives and copy the figures it
prints into Section 3.11.1 and Table 3; ``docs/REPORTED_NUMBERS.md`` lists
exactly which sentence each number belongs to.
"""
from __future__ import annotations

import json
from collections import defaultdict
from dataclasses import dataclass, asdict, field
from pathlib import Path

import numpy as np
import pandas as pd

from .config import SPLIT_FRACTIONS


# --------------------------------------------------------------------------
# Metadata containers
# --------------------------------------------------------------------------
@dataclass
class Archive:
    """Image-level metadata for one dataset.

    Required columns: ``image_id``, ``lesion_id``. Classification archives
    additionally carry ``label``. ``isic_id`` is used for cross-dataset
    matching when present.
    """

    name: str
    frame: pd.DataFrame

    def __post_init__(self):
        missing = {'image_id', 'lesion_id'} - set(self.frame.columns)
        if missing:
            raise ValueError(f'{self.name}: missing columns {sorted(missing)}')
        if 'isic_id' not in self.frame.columns:
            self.frame = self.frame.assign(isic_id=self.frame['image_id'])

    @property
    def lesions(self) -> set[str]:
        return set(self.frame['lesion_id'])

    def images_of(self, lesions) -> pd.DataFrame:
        return self.frame[self.frame['lesion_id'].isin(set(lesions))]


def load_archive(name: str, path: str | Path) -> Archive:
    return Archive(name, pd.read_csv(path, dtype=str))


# --------------------------------------------------------------------------
# Cross-dataset matching
# --------------------------------------------------------------------------
def match_lesions(seg: Archive, cls: Archive) -> dict[str, set[str]]:
    """Match segmentation lesions to classification lesions.

    Primary key is ``isic_id``; where that identifier is absent on either
    side, ``lesion_id`` is used instead. Returns a mapping from a segmentation
    lesion_id to the set of classification lesion_ids it corresponds to.
    """
    by_isic = defaultdict(set)
    for isic_id, lesion in zip(cls.frame['isic_id'], cls.frame['lesion_id']):
        if isinstance(isic_id, str) and isic_id:
            by_isic[isic_id].add(lesion)
    by_lesion = defaultdict(set)
    for lesion in cls.frame['lesion_id']:
        by_lesion[lesion].add(lesion)

    matched: dict[str, set[str]] = defaultdict(set)
    for isic_id, lesion in zip(seg.frame['isic_id'], seg.frame['lesion_id']):
        hit = by_isic.get(isic_id)
        if not hit:
            hit = by_lesion.get(lesion)
        if hit:
            matched[lesion] |= hit
    return dict(matched)


# --------------------------------------------------------------------------
# Splitting
# --------------------------------------------------------------------------
def _group_table(frame: pd.DataFrame) -> pd.DataFrame:
    """One row per lesion: its label and how many acquisitions it has."""
    label = ('label' if 'label' in frame.columns else None)
    agg = {'image_id': 'count'}
    if label:
        agg[label] = 'first'
    g = frame.groupby('lesion_id').agg(agg).rename(
        columns={'image_id': 'n_images'}).reset_index()
    if not label:
        g['label'] = '_'
    return g


def stratified_group_split(frame: pd.DataFrame, seed: int,
                           fractions=SPLIT_FRACTIONS,
                           forced_train: set[str] | None = None
                           ) -> dict[str, list[str]]:
    """Stratified, lesion-grouped train/val/test split.

    Stratification preserves the class distribution; grouping keeps every
    acquisition of a lesion in one subset (Section 3.11). Lesions in
    ``forced_train`` are placed in train before anything else is drawn, which
    is rule (i).

    Target fractions are applied to the *image* count of each class, so the
    realised counts depart slightly from 80/10/10 whenever a lesion carries
    several acquisitions - exactly the effect Table 3's note describes.
    """
    forced_train = set(forced_train or ())
    groups = _group_table(frame)
    rng = np.random.default_rng(seed)
    out = {'train': [], 'val': [], 'test': []}

    for label, block in groups.groupby('label', sort=True):
        block = block.sample(frac=1.0, random_state=int(rng.integers(1 << 31)))
        free, forced = [], []
        for lesion, n in zip(block['lesion_id'], block['n_images']):
            (forced if lesion in forced_train else free).append((lesion, int(n)))
        out['train'].extend(lesion for lesion, _ in forced)

        total_free = sum(n for _, n in free)
        want_test = int(round(total_free * fractions[2]))
        want_val = int(round(total_free * fractions[1]))
        # Stratification is only meaningful if every class that can be
        # represented in validation and test actually is. For the real
        # archives the rounding above already guarantees this; the guard
        # matters for rare classes and for small runs, where round(n * 0.1)
        # would otherwise be zero and the class would vanish from the
        # held-out splits altogether.
        if len(free) >= 3:
            want_test = max(want_test, 1)
            want_val = max(want_val, 1)
        acc_test = acc_val = 0
        for lesion, n in free:
            if acc_test < want_test:
                out['test'].append(lesion)
                acc_test += n
            elif acc_val < want_val:
                out['val'].append(lesion)
                acc_val += n
            else:
                out['train'].append(lesion)
    return out


# --------------------------------------------------------------------------
# The protocol
# --------------------------------------------------------------------------
@dataclass
class SplitResult:
    seed: int
    segmentation: dict = field(default_factory=dict)
    classification: dict = field(default_factory=dict)
    leakage: dict = field(default_factory=dict)

    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=2, sort_keys=True)


def build_splits(seg: Archive, classification: dict[str, Archive],
                 seed: int) -> SplitResult:
    """Build every partition for one seed, applying both leakage rules.

    Returns a :class:`SplitResult` whose ``leakage`` field carries the counts
    the manuscript quotes in Section 3.11.1 and Table 3.
    """
    result = SplitResult(seed=seed)

    # ---- ISIC 2018 Task 1: one acquisition per lesion, so grouping is a no-op
    seg_groups = _group_table(seg.frame)
    multi = int((seg_groups['n_images'] > 1).sum())
    seg_split = stratified_group_split(seg.frame, seed)
    seg_images = {k: sorted(seg.images_of(v)['image_id']) for k, v in seg_split.items()}
    result.segmentation = {
        'lesions': {k: sorted(v) for k, v in seg_split.items()},
        'images': seg_images,
        'counts': {k: len(v) for k, v in seg_images.items()},
        'lesions_with_multiple_acquisitions': multi,
    }

    seg_train_lesions = set(seg_split['train'])
    seg_heldout_lesions = set(seg_split['val']) | set(seg_split['test'])

    # ---- classification archives
    for name, arc in classification.items():
        matched = match_lesions(seg, arc)

        force, exclude = set(), set()
        for seg_lesion, cls_lesions in matched.items():
            if seg_lesion in seg_heldout_lesions:
                exclude |= cls_lesions          # rule (ii)
            elif seg_lesion in seg_train_lesions:
                force |= cls_lesions            # rule (i)
        # a lesion that matches both ways is excluded: rule (ii) dominates
        force -= exclude

        released_images = len(arc.frame)
        pool = arc.frame[~arc.frame['lesion_id'].isin(exclude)]
        split = stratified_group_split(pool, seed, forced_train=force)
        images = {k: sorted(pool[pool['lesion_id'].isin(set(v))]['image_id'])
                  for k, v in split.items()}

        result.classification[name] = {
            'lesions': {k: sorted(v) for k, v in split.items()},
            'images': images,
            'counts': {k: len(v) for k, v in images.items()},
            'pool_images': int(len(pool)),
            'released_images': int(released_images),
        }
        result.leakage[name] = {
            'matched_segmentation_lesions': len(matched),
            'rule_i_forced_to_train_lesions': len(force),
            'rule_ii_excluded_lesions': len(exclude),
            'rule_ii_excluded_images': int(released_images - len(pool)),
            'pool_after_exclusion_images': int(len(pool)),
            'released_images': int(released_images),
        }
    return result


def verify_leakage(result: SplitResult) -> dict:
    """Reproduce the check reported in Section 3.11.1.

    Asserts that the intersection between the ISIC 2018 Task 1 validation and
    test lesion sets and the union of the classification training and
    validation lesion sets is empty, and that the same holds at image level
    after expanding every lesion to all of its acquisitions.

    Raises ``AssertionError`` on any violation, so it is safe to call in CI.
    """
    held_lesions = set(result.segmentation['lesions']['val']) | \
        set(result.segmentation['lesions']['test'])
    held_images = set(result.segmentation['images']['val']) | \
        set(result.segmentation['images']['test'])

    report = {'seed': result.seed, 'checks': {}}
    for name, block in result.classification.items():
        seen_lesions = set(block['lesions']['train']) | set(block['lesions']['val'])
        seen_images = set(block['images']['train']) | set(block['images']['val'])
        lesion_overlap = sorted(held_lesions & seen_lesions)
        image_overlap = sorted(held_images & seen_images)

        # rule (i): no Stage-1 training image in a classification val/test split
        train_lesions = set(result.segmentation['lesions']['train'])
        evaluated = set(block['lesions']['val']) | set(block['lesions']['test'])
        rule_i_overlap = sorted(train_lesions & evaluated)

        report['checks'][name] = {
            'rule_ii_lesion_overlap': lesion_overlap,
            'rule_ii_image_overlap': image_overlap,
            'rule_i_lesion_overlap': rule_i_overlap,
            'passed': not (lesion_overlap or image_overlap or rule_i_overlap),
        }
        assert not lesion_overlap, (
            f'{name}: rule (ii) violated, {len(lesion_overlap)} ISIC 2018 '
            f'held-out lesions reached a classification training/validation split')
        assert not image_overlap, (
            f'{name}: rule (ii) violated at image level, {len(image_overlap)} images')
        assert not rule_i_overlap, (
            f'{name}: rule (i) violated, {len(rule_i_overlap)} Stage-1 training '
            f'lesions reached a classification validation/test split')
    report['passed'] = all(c['passed'] for c in report['checks'].values())
    return report


def write_split_files(result: SplitResult, out_dir: str | Path) -> Path:
    """Write the released split index files for one seed."""
    out = Path(out_dir) / f'seed{result.seed}'
    out.mkdir(parents=True, exist_ok=True)
    (out / 'split_index.json').write_text(result.to_json(), encoding='utf-8')
    (out / 'leakage_counts.json').write_text(
        json.dumps(result.leakage, indent=2, sort_keys=True), encoding='utf-8')
    for split in ('train', 'val', 'test'):
        (out / f'isic2018_{split}_images.txt').write_text(
            '\n'.join(result.segmentation['images'][split]) + '\n', encoding='utf-8')
        for name, block in result.classification.items():
            (out / f'{name}_{split}_images.txt').write_text(
                '\n'.join(block['images'][split]) + '\n', encoding='utf-8')
    return out
