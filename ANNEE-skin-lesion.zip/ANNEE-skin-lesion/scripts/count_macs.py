#!/usr/bin/env python3
"""Regenerate Table 2 and the capacity columns of Table 10.

One counter, one convention, applied to every model, so that the figures are
comparable by construction rather than by assertion. The convention is stated
in Section 4.2 and implemented in ``annee/macs.py``:

    one MAC = one multiply-accumulate = two floating-point operations;
    convolution, transposed-convolution, linear and attention-projection
    layers are counted; batch normalisation, activations, pooling,
    interpolation and element-wise operations are not; batch-normalisation
    parameters are counted within the preceding convolution; every figure is
    for a single 256 x 256 RGB image, inference mode, batch size 1.

The parameter column counts trainable parameters.

Usage
    python scripts/count_macs.py                 # Table 2
    python scripts/count_macs.py --baselines     # Table 2 + Table 10 capacity
    python scripts/count_macs.py --out artifacts/tables/table2.json
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from annee.config import IMAGE_SIZE
from annee.macs import count_model, annee_group, classical_stage_macs
from annee.models import (build_segmentation_network, build_classifier,
                          build_vanilla_unet)

ROW = '  {:<34}{:>14}{:>13}{:>10}'


def table2(size: int = IMAGE_SIZE, num_classes: int = 8) -> dict:
    seg = count_model(build_segmentation_network(image_size=size), annee_group)
    cls = count_model(build_classifier(num_classes, image_size=size), annee_group)
    total_macs = seg['total_macs'] + cls['total_macs']
    total_params = seg['total_params'] + cls['total_params']

    print(f'Table 2. Layer-wise computational cost at {size} x {size}\n')
    print(ROW.format('stage', 'parameters', 'MMAC', '% of MACs'))
    print('  ' + '-' * 69)
    order = ['attention gate', 'encoder', 'residual bottleneck', 'decoder',
             'output heads']
    for g in order:
        if g not in seg['groups']:
            continue
        b = seg['groups'][g]
        print(ROW.format(g, f"{b['params']:,}", f"{b['mmac']:,.1f}",
                         f"{100 * b['macs'] / total_macs:.2f}"))
    print(ROW.format('segmentation subtotal', f"{seg['total_params']:,}",
                     f"{seg['total_mmac']:,.1f}",
                     f"{100 * seg['total_macs'] / total_macs:.2f}"))
    print(ROW.format('classification network', f"{cls['total_params']:,}",
                     f"{cls['total_mmac']:,.1f}",
                     f"{100 * cls['total_macs'] / total_macs:.2f}"))
    print('  ' + '-' * 69)
    print(ROW.format('pipeline total', f'{total_params:,}',
                     f'{total_macs / 1e6:,.1f}', '100.00'))
    print(f'\n  = {total_params / 1e6:.2f} M parameters, '
          f'{total_macs / 1e9:.2f} GMAC, about '
          f'{2 * total_macs / 1e9:.1f} GFLOPs per forward pass')

    classical = classical_stage_macs(size)
    print('\n  classical stages (listed for reference, excluded from the totals)')
    for k, v in classical.items():
        print(f'    {k:<32}{v / 1e6:>10.3f} MMAC')
    print(f"    {'subtotal':<32}{sum(classical.values()) / 1e6:>10.3f} MMAC"
          f"  ({100 * sum(classical.values()) / total_macs:.3f}% of the "
          f"learnable layers)")

    return {'segmentation': seg, 'classification': cls,
            'pipeline': {'params': total_params, 'macs': total_macs,
                         'params_m': total_params / 1e6,
                         'gmac': total_macs / 1e9,
                         'gflops': 2 * total_macs / 1e9},
            'classical_stages_macs': classical}


def table10_capacity(size: int = IMAGE_SIZE, num_classes: int = 8) -> dict:
    """Capacity columns of Table 10, every entry through the same counter."""
    from annee.baselines import build_baseline, BASELINES

    print(f'\n\nTable 10 capacity columns at {size} x {size}\n')
    print(ROW.format('model', 'params (M)', 'GMAC', ''))
    print('  ' + '-' * 69)
    rows = {}

    u = count_model(build_vanilla_unet(image_size=size))
    rows['U-Net (reimplemented, 32-512)'] = u
    print(ROW.format('U-Net (reimplemented, 32-512)',
                     f"{u['total_params_m']:.2f}", f"{u['total_gmac']:.2f}", ''))

    for key in BASELINES:
        try:
            m = build_baseline(key, image_size=size, num_classes=num_classes)
        except Exception as exc:                       # pragma: no cover
            print(ROW.format(key, 'unavailable', str(exc)[:30], ''))
            continue
        c = count_model(m)
        rows[key] = c
        print(ROW.format(BASELINES[key]['label'], f"{c['total_params_m']:.2f}",
                         f"{c['total_gmac']:.2f}", ''))

    seg = count_model(build_segmentation_network(image_size=size))
    cls = count_model(build_classifier(num_classes, image_size=size))
    print('  ' + '-' * 69)
    print(ROW.format('Proposed ANNEE (segmentation)',
                     f"{seg['total_params_m']:.2f}", f"{seg['total_gmac']:.2f}", ''))
    print(ROW.format('Proposed ANNEE - classification network alone',
                     f"{cls['total_params_m']:.2f}", f"{cls['total_gmac']:.2f}", ''))
    tp = seg['total_params'] + cls['total_params']
    tm = seg['total_macs'] + cls['total_macs']
    print(ROW.format('Proposed ANNEE - complete pipeline',
                     f'{tp / 1e6:.2f}', f'{tm / 1e9:.2f}', ''))
    print('\n  The classification network alone cannot be run on a raw image: '
          'its five\n  input channels are produced by the segmentation network, '
          'so the row that\n  compares with the ImageNet backbones is the '
          'complete pipeline.')
    rows['annee_segmentation'] = seg
    rows['annee_classifier'] = cls
    rows['annee_pipeline'] = {'total_params': tp, 'total_macs': tm,
                              'total_params_m': tp / 1e6, 'total_gmac': tm / 1e9}
    return rows


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--size', type=int, default=IMAGE_SIZE)
    ap.add_argument('--classes', type=int, default=8)
    ap.add_argument('--baselines', action='store_true')
    ap.add_argument('--out', default=None)
    args = ap.parse_args(argv)

    result = {'table2': table2(args.size, args.classes)}
    if args.baselines:
        result['table10'] = table10_capacity(args.size, args.classes)
    if args.out:
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        def _clean(o):
            if isinstance(o, dict):
                return {k: _clean(v) for k, v in o.items() if k != 'layers'}
            return o
        Path(args.out).write_text(json.dumps(_clean(result), indent=2),
                                  encoding='utf-8')
        print(f'\nwrote {args.out}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
