#!/usr/bin/env python3
"""Run one variant, one seed, end to end: Stages 1-3 and the predictions.

    python scripts/run_experiment.py --variant A --seed 0 --dataset isic2019 \
        --data-root data --out artifacts

What it does, in order:

    1. load the split index for this seed (scripts/make_splits.py must have run)
    2. Stage 1 on ISIC 2018 Task 1, Eq. (15a)          -> stage1.weights.h5
    3. Stage 2 on the classification archive, Eq. (15b) -> stage2_<archive>.weights.h5
    4. Stage 3 jointly, Eq. (15c), unless the variant disables it
                                                        -> stage3_<archive>_*.weights.h5
    5. segmentation predictions on the ISIC 2018 test split, from the
       checkpoint that Table 9 reports for this variant
    6. classification predictions on the archive's test split

Step 5 is where Reviewer 2's first request is settled in code:
``annee.variants.checkpoint_stage`` decides which checkpoint is loaded, and the
choice is written into the prediction manifest.
"""
from __future__ import annotations

import argparse
import dataclasses
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from annee.config import RunConfig, SEEDS, DATASETS
from annee.data import (segmentation_dataset, classification_dataset,
                        make_segmentation_sample, make_classification_sample,
                        label_index)
from annee.models import build_models
from annee.predict import predict_segmentation, predict_classification
from annee.train import (train_stage1, train_stage2, train_stage3,
                         write_run_manifest)
from annee.variants import apply_variant, checkpoint_stage


def load_split(splits_root: Path, seed: int) -> dict:
    p = Path(splits_root) / f'seed{seed}' / 'split_index.json'
    if not p.exists():
        raise SystemExit(f'{p} not found - run scripts/make_splits.py first')
    return json.loads(p.read_text())


def _labels_for(data_root: Path, dataset: str, image_ids: list[str]):
    import pandas as pd
    df = pd.read_csv(Path(data_root) / dataset / 'metadata.csv', dtype=str)
    idx = label_index(dataset)
    lut = dict(zip(df['image_id'], df['label']))
    return [idx[lut[i]] for i in image_ids]


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--variant', default='A')
    ap.add_argument('--seed', type=int, default=0, choices=list(SEEDS))
    ap.add_argument('--dataset', default='isic2019',
                    choices=['isic2019', 'ham10000'])
    ap.add_argument('--data-root', default='data')
    ap.add_argument('--out', default='artifacts')
    ap.add_argument('--splits', default=None)
    ap.add_argument('--epochs', type=int, default=None)
    ap.add_argument('--size', type=int, default=None,
                    help='override the working resolution (smoke runs only)')
    args = ap.parse_args(argv)

    cfg = apply_variant(RunConfig(seed=args.seed, dataset=args.dataset,
                                  data_root=args.data_root, out_root=args.out),
                        args.variant)
    if args.epochs:
        cfg = dataclasses.replace(cfg, max_epochs=args.epochs,
                                  stage3_epochs=args.epochs)
    if args.size:
        cfg = dataclasses.replace(cfg, image_size=args.size)

    out = Path(args.out)
    ckpt_dir = out / 'checkpoints' / cfg.tag
    pred_dir = out / 'predictions' / cfg.tag
    splits_root = Path(args.splits or out / 'splits')
    split = load_split(splits_root, cfg.seed)

    seg_ids = split['segmentation']['images']
    cls_ids = split['classification'][cfg.dataset]['images']
    root = Path(cfg.data_root)

    seg_model, cls_model = build_models(cfg)
    results = {}

    # ---- Stage 1 ----------------------------------------------------------
    print(f'[{cfg.tag}] Stage 1: segmentation pre-training, Eq. (15a)')
    results['stage1'] = train_stage1(
        seg_model,
        segmentation_dataset(root, seg_ids['train'], cfg.image_size,
                             cfg.batch_size, training=True,
                             use_augmentation=cfg.use_augmentation,
                             operator=cfg.edge_operator, seed=cfg.seed),
        segmentation_dataset(root, seg_ids['val'], cfg.image_size,
                             cfg.batch_size, operator=cfg.edge_operator),
        ckpt_dir, cfg, epochs=cfg.max_epochs)

    # ---- Stage 2 ----------------------------------------------------------
    print(f'[{cfg.tag}] Stage 2: classifier pre-training, Eq. (15b)')
    y_train = _labels_for(root, cfg.dataset, cls_ids['train'])
    counts = np.bincount(y_train, minlength=cfg.num_classes)
    results['stage2'] = train_stage2(
        seg_model, cls_model,
        classification_dataset(root, cfg.dataset, cls_ids['train'], y_train,
                               cfg.num_classes, cfg.image_size, cfg.batch_size,
                               training=True,
                               use_augmentation=cfg.use_augmentation,
                               operator=cfg.edge_operator, seed=cfg.seed),
        classification_dataset(root, cfg.dataset, cls_ids['val'],
                               _labels_for(root, cfg.dataset, cls_ids['val']),
                               cfg.num_classes, cfg.image_size, cfg.batch_size,
                               operator=cfg.edge_operator),
        ckpt_dir, cfg, class_counts=counts, epochs=cfg.max_epochs)

    # ---- Stage 3 ----------------------------------------------------------
    if cfg.use_joint_finetuning:
        print(f'[{cfg.tag}] Stage 3: joint fine-tuning on {cfg.dataset}, Eq. (15c)')
        results['stage3'] = train_stage3(
            seg_model, cls_model,
            classification_dataset(root, cfg.dataset, cls_ids['train'], y_train,
                                   cfg.num_classes, cfg.image_size,
                                   cfg.batch_size, training=True,
                                   use_augmentation=cfg.use_augmentation,
                                   operator=cfg.edge_operator, seed=cfg.seed),
            classification_dataset(root, cfg.dataset, cls_ids['val'],
                                   _labels_for(root, cfg.dataset, cls_ids['val']),
                                   cfg.num_classes, cfg.image_size,
                                   cfg.batch_size, operator=cfg.edge_operator),
            ckpt_dir, cfg, class_counts=counts, lam=cfg.lambda_class,
            epochs=cfg.stage3_epochs)
    else:
        print(f'[{cfg.tag}] Stage 3 skipped (variant {cfg.variant})')
        results['stage3'] = None

    # ---- predictions ------------------------------------------------------
    stage = checkpoint_stage(cfg.variant) if cfg.use_joint_finetuning else 'stage1'
    if stage == 'stage1':
        seg_model.load_weights(ckpt_dir / 'stage1.weights.h5')
    print(f'[{cfg.tag}] segmentation predictions from the {stage} checkpoint')
    seg_samples = (make_segmentation_sample(root, i, cfg.image_size,
                                            cfg.edge_operator)
                   for i in seg_ids['test'])
    predict_segmentation(seg_model, seg_samples, pred_dir / 'segmentation',
                         stage=stage,
                         archive=cfg.dataset if stage == 'stage3' else None,
                         variant=cfg.variant,
                         use_morphology=cfg.use_morphology)

    print(f'[{cfg.tag}] classification predictions')
    y_test = _labels_for(root, cfg.dataset, cls_ids['test'])
    cls_samples = (dict(make_classification_sample(root, cfg.dataset, i, y,
                                                   cfg.image_size,
                                                   cfg.edge_operator))
                   for i, y in zip(cls_ids['test'], y_test))
    predict_classification(seg_model, cls_model, cls_samples,
                           pred_dir / 'classification',
                           stage=stage, archive=cfg.dataset,
                           variant=cfg.variant,
                           class_names=DATASETS[cfg.dataset]['classes'],
                           use_morphology=cfg.use_morphology)

    write_run_manifest(ckpt_dir, cfg, results)
    print(f'[{cfg.tag}] done: checkpoints in {ckpt_dir}, predictions in {pred_dir}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
