#!/usr/bin/env python3
"""End-to-end smoke run on a tiny synthetic dataset.

The real archives are large and are not redistributed with this repository,
so there has to be some way to check that the pipeline runs before committing
a GPU to it. This script fabricates a handful of small images with
elliptical "lesions", writes them in the expected layout, and then runs the
whole protocol: splits, leakage verification, Stages 1-3, predictions, and
both metric scripts.

It proves that the code executes and that the artefacts have the right shape.
It proves nothing about accuracy: the images are synthetic and the runs are a
couple of epochs on a few dozen samples.

    python scripts/smoke_test.py --work /tmp/annee_smoke
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

REPO = Path(__file__).resolve().parents[1]


def _ellipse(size, cy, cx, ry, rx, angle):
    yy, xx = np.mgrid[:size, :size]
    ca, sa = np.cos(angle), np.sin(angle)
    y, x = yy - cy, xx - cx
    yr, xr = y * ca + x * sa, -y * sa + x * ca
    return ((yr / ry) ** 2 + (xr / rx) ** 2 <= 1.0)


def synth(work: Path, n_seg=24, n_cls=48, size=64, overlap=8, seed=0):
    from PIL import Image
    rng = np.random.default_rng(seed)
    data = work / 'data'
    for d in ('isic2018/images', 'isic2018/masks', 'isic2019/images',
              'ham10000/images'):
        (data / d).mkdir(parents=True, exist_ok=True)

    def make(path_img, path_mask=None):
        base = rng.uniform(0.55, 0.8, 3)
        img = np.ones((size, size, 3), np.float32) * base
        img += rng.normal(0, 0.03, img.shape)
        m = _ellipse(size, rng.uniform(.3, .7) * size, rng.uniform(.3, .7) * size,
                     rng.uniform(.10, .22) * size, rng.uniform(.10, .22) * size,
                     rng.uniform(0, np.pi))
        img[m] *= rng.uniform(0.25, 0.5)
        img = np.clip(img, 0, 1)
        Image.fromarray((img * 255).astype(np.uint8)).save(path_img)
        if path_mask is not None:
            Image.fromarray((m * 255).astype(np.uint8)).save(path_mask)

    seg_rows = []
    for i in range(n_seg):
        iid = f'ISIC_SEG{i:04d}'
        make(data / 'isic2018/images' / f'{iid}.jpg',
             data / 'isic2018/masks' / f'{iid}_segmentation.png')
        seg_rows.append({'image_id': iid, 'lesion_id': f'LES{i:04d}',
                         'isic_id': f'ISICID{i:06d}'})

    import pandas as pd
    pd.DataFrame(seg_rows).to_csv(data / 'isic2018/metadata.csv', index=False)

    for name, classes in (('isic2019', ('MEL', 'NV', 'BCC', 'AK', 'BKL', 'DF',
                                        'VASC', 'SCC')),
                          ('ham10000', ('akiec', 'bcc', 'bkl', 'df', 'mel',
                                        'nv', 'vasc'))):
        rows = []
        for j in range(n_cls):
            iid = f'{name.upper()}_{j:04d}'
            make(data / name / 'images' / f'{iid}.jpg')
            if j < overlap:          # deliberate overlap with the seg benchmark
                lesion, isic = f'LES{j:04d}', f'ISICID{j:06d}'
            else:
                lesion, isic = f'{name}LES{j:04d}', f'{name}ID{j:06d}'
            rows.append({'image_id': iid, 'lesion_id': lesion, 'isic_id': isic,
                         'label': classes[j % len(classes)]})
        pd.DataFrame(rows).to_csv(data / name / 'metadata.csv', index=False)
    return data


def run(cmd, **kw):
    print('\n$ ' + ' '.join(str(c) for c in cmd))
    r = subprocess.run([sys.executable, *cmd], cwd=REPO, **kw)
    if r.returncode:
        raise SystemExit(f'step failed: {cmd[0]}')
    return r


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--work', default='/tmp/annee_smoke')
    ap.add_argument('--keep', action='store_true')
    args = ap.parse_args(argv)

    work = Path(args.work)
    if work.exists() and not args.keep:
        shutil.rmtree(work)
    work.mkdir(parents=True, exist_ok=True)
    data = synth(work)
    out = work / 'artifacts'
    print(f'synthetic dataset written to {data}')

    run(['scripts/make_splits.py', '--data-root', str(data),
         '--out', str(out / 'splits'), '--seeds', '0'])
    run(['scripts/verify_leakage.py', '--splits', str(out / 'splits')])
    run(['scripts/run_experiment.py', '--variant', 'A', '--seed', '0',
         '--dataset', 'isic2019', '--data-root', str(data), '--out', str(out),
         '--epochs', '1'])
    run(['scripts/seg_metrics.py', '--predictions',
         str(out / 'predictions/A_isic2019_seed0/segmentation'),
         '--ground-truth', str(data / 'isic2018/masks'),
         '--out', str(out / 'tables/table9_smoke.json')])
    run(['scripts/cls_metrics.py', '--predictions',
         str(out / 'predictions/A_isic2019_seed0/classification/predictions.csv'),
         '--out', str(out / 'tables/table4_smoke.json')])
    run(['scripts/count_macs.py', '--out', str(out / 'tables/table2.json')])

    # ---- check the artefacts Section 3.12 promises are actually there -----
    pred = out / 'predictions/A_isic2019_seed0'
    expected = [
        pred / 'segmentation/manifest.json',
        pred / 'segmentation/masks',
        pred / 'segmentation/region_prob',
        pred / 'segmentation/boundary_prob',
        pred / 'classification/predictions.csv',
        pred / 'classification/manifest.json',
        out / 'checkpoints/A_isic2019_seed0/stage1.weights.h5',
        out / 'checkpoints/A_isic2019_seed0/stage1_log.json',
        out / 'checkpoints/A_isic2019_seed0/run_manifest.json',
        out / 'splits/seed0/split_index.json',
        out / 'splits/seed0/leakage_counts.json',
    ]
    print('\nartefact check')
    missing = []
    for p in expected:
        ok = p.exists()
        print(f'  {"OK " if ok else "MISSING"}  {p.relative_to(work)}')
        if not ok:
            missing.append(p)

    manifest = json.loads((pred / 'segmentation/manifest.json').read_text())
    print(f"\nsegmentation manifest records checkpoint_stage="
          f"{manifest['checkpoint_stage']!r}, finetuned_on="
          f"{manifest['finetuned_on']!r}")
    log = json.loads((out / 'checkpoints/A_isic2019_seed0/stage1_log.json').read_text())
    print(f"stage 1 log keeps the weight trajectory: "
          f"s_e={log[-1]['s_e']:.4f}, s_l={log[-1]['s_l']:.4f}, "
          f"alpha_norm={log[-1]['alpha_norm']:.4f}, "
          f"beta_norm={log[-1]['beta_norm']:.4f}")

    if missing:
        print(f'\nSMOKE TEST FAILED: {len(missing)} artefacts missing')
        return 1
    print('\nSMOKE TEST PASSED - the pipeline runs end to end and writes '
          'every artefact Section 3.12 promises.')
    if not args.keep:
        shutil.rmtree(work, ignore_errors=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
