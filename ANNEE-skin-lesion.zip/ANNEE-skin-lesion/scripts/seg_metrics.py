#!/usr/bin/env python3
"""Recompute Table 9 from released predictions. No model, no retraining.

This is the script Section 3.12 names: "the Dice, IoU, sensitivity,
specificity, boundary-F and HD95 columns of Table 9 are recomputed from the
released prediction masks and the official ISIC 2018 Task 1 ground-truth masks
by the script seg_metrics.py".

Usage
    python scripts/seg_metrics.py \
        --predictions artifacts/predictions/A_seed0/segmentation \
        --ground-truth data/isic2018/masks \
        --out artifacts/tables/table9_A_seed0.json

    # all five seeds of one variant, with the mean +- sd Table 9 reports
    python scripts/seg_metrics.py \
        --predictions artifacts/predictions/A_seed{0,1,2,3,4}/segmentation \
        --ground-truth data/isic2018/masks --aggregate

The manifest written beside the masks records which checkpoint produced them,
and that stage is carried into the output so a Table 9 row is never ambiguous.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from annee.metrics import segmentation_metrics, aggregate_segmentation, SEG_METRICS
from annee.preprocessing import np_resize_mask
from annee.config import IMAGE_SIZE


def _load_mask(path: Path, size: int) -> np.ndarray:
    from PIL import Image
    with Image.open(path) as im:
        a = np.asarray(im.convert('L'), np.float32) / 255.0
    if a.shape[0] != size or a.shape[1] != size:
        a = np_resize_mask(a, size)
    return (a > 0.5).astype(np.float32)


def _ground_truth_path(root: Path, image_id: str) -> Path:
    for pattern in (f'{image_id}_segmentation.png', f'{image_id}.png'):
        p = root / pattern
        if p.exists():
            return p
    raise FileNotFoundError(f'no ground-truth mask for {image_id} under {root}')


def evaluate_run(pred_dir: Path, gt_dir: Path, size: int = IMAGE_SIZE) -> dict:
    manifest_path = pred_dir / 'manifest.json'
    manifest = json.loads(manifest_path.read_text()) if manifest_path.exists() else {}
    mask_dir = pred_dir / 'masks'
    per_image = []
    for mp in sorted(mask_dir.glob('*.png')):
        image_id = mp.stem
        pred = _load_mask(mp, size)
        true = _load_mask(_ground_truth_path(gt_dir, image_id), size)
        per_image.append({'image_id': image_id, **segmentation_metrics(pred, true)})
    if not per_image:
        raise SystemExit(f'no predicted masks found in {mask_dir}')
    return {
        'run': pred_dir.parent.name,
        'variant': manifest.get('variant'),
        'checkpoint_stage': manifest.get('checkpoint_stage'),
        'finetuned_on': manifest.get('finetuned_on'),
        'n_images': len(per_image),
        'mean': aggregate_segmentation(per_image),
        'per_image': per_image,
    }


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--predictions', nargs='+', required=True,
                    help='one or more <run>/segmentation directories')
    ap.add_argument('--ground-truth', required=True,
                    help='directory of official ISIC 2018 Task 1 masks')
    ap.add_argument('--out', default=None, help='write JSON here')
    ap.add_argument('--aggregate', action='store_true',
                    help='also report mean +- sd across the runs given')
    ap.add_argument('--size', type=int, default=IMAGE_SIZE)
    args = ap.parse_args(argv)

    gt = Path(args.ground_truth)
    runs = [evaluate_run(Path(p), gt, args.size) for p in args.predictions]

    for r in runs:
        stage = r['checkpoint_stage'] or 'unknown'
        print(f"{r['run']}  variant={r['variant']}  checkpoint={stage}"
              f"  n={r['n_images']}")
        print('   ' + '  '.join(f'{k}={r["mean"][k]:.4f}' for k in SEG_METRICS))

    out = {'runs': runs}
    if args.aggregate and len(runs) > 1:
        stages = {r['checkpoint_stage'] for r in runs}
        if len(stages) > 1:
            print(f'WARNING: mixing checkpoints {sorted(stages)} in one '
                  f'aggregate; Table 9 rows must come from a single stage',
                  file=sys.stderr)
        agg = {}
        for k in SEG_METRICS:
            vals = np.array([r['mean'][k] for r in runs], float)
            agg[k] = {'mean': float(vals.mean()), 'sd': float(vals.std(ddof=1))
                      if len(vals) > 1 else 0.0}
        out['aggregate'] = {'n_runs': len(runs), 'checkpoint_stages': sorted(stages),
                            'metrics': agg}
        print('\nmean +- sd over %d runs (the form Table 9 reports):' % len(runs))
        for k in SEG_METRICS:
            print(f'   {k:<12} {agg[k]["mean"]*(100 if k != "hd95" else 1):.1f}'
                  f' +- {agg[k]["sd"]*(100 if k != "hd95" else 1):.1f}')

    if args.out:
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.out).write_text(json.dumps(out, indent=2), encoding='utf-8')
        print(f'\nwrote {args.out}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
