#!/usr/bin/env python3
"""Build the partitions for all five seeds and print the Section 3.11.1 counts.

This script produces the split index files released with the paper, applies
both leakage-control rules, verifies them against the realised assignments and
prints every number that Section 3.11.1 and Table 3 quote. Copy its output
into the manuscript rather than the other way round; the numbers currently in
the text must agree with what this prints on the real archives.

Usage
    python scripts/make_splits.py --data-root data --out artifacts/splits
    python scripts/make_splits.py --data-root data --out artifacts/splits --seeds 0
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from annee.config import SEEDS
from annee.splits import (load_archive, build_splits, verify_leakage,
                          write_split_files)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--data-root', default='data')
    ap.add_argument('--out', default='artifacts/splits')
    ap.add_argument('--seeds', type=int, nargs='+', default=list(SEEDS))
    args = ap.parse_args(argv)

    root = Path(args.data_root)
    seg = load_archive('isic2018', root / 'isic2018' / 'metadata.csv')
    classification = {
        'isic2019': load_archive('isic2019', root / 'isic2019' / 'metadata.csv'),
        'ham10000': load_archive('ham10000', root / 'ham10000' / 'metadata.csv'),
    }

    summary = {}
    for seed in args.seeds:
        result = build_splits(seg, classification, seed)
        report = verify_leakage(result)          # raises on any violation
        path = write_split_files(result, args.out)
        summary[seed] = {'leakage': result.leakage,
                         'segmentation_counts': result.segmentation['counts'],
                         'classification_counts': {
                             k: v['counts'] for k, v in result.classification.items()},
                         'pool': {k: v['pool_images']
                                  for k, v in result.classification.items()},
                         'released': {k: v['released_images']
                                      for k, v in result.classification.items()},
                         'verification': report}
        print(f'seed {seed}: splits written to {path}, leakage check passed')

    Path(args.out).mkdir(parents=True, exist_ok=True)
    (Path(args.out) / 'summary.json').write_text(
        json.dumps(summary, indent=2, sort_keys=True), encoding='utf-8')

    # ---- the sentences of Section 3.11.1 and the cells of Table 3 ----------
    ref = summary[args.seeds[0]]
    print('\n' + '=' * 78)
    print('NUMBERS FOR THE MANUSCRIPT  (seed %d; see docs/REPORTED_NUMBERS.md)'
          % args.seeds[0])
    print('=' * 78)
    seg_counts = ref['segmentation_counts']
    print(f"Section 3.11.2  ISIC 2018 Task 1 split: "
          f"{seg_counts['train']} train / {seg_counts['val']} validation / "
          f"{seg_counts['test']} test")
    for name, lk in ref['leakage'].items():
        print(f'\nSection 3.11.1, {name}:')
        print(f"  matched segmentation lesions .......... {lk['matched_segmentation_lesions']:,}")
        print(f"  rule (i)  forced into train (lesions) . {lk['rule_i_forced_to_train_lesions']:,}")
        print(f"  rule (ii) excluded (lesions) .......... {lk['rule_ii_excluded_lesions']:,}")
        print(f"  rule (ii) excluded (images) ........... {lk['rule_ii_excluded_images']:,}")
        print(f"  pool after exclusion .................. {lk['pool_after_exclusion_images']:,}"
              f"  (released {lk['released_images']:,})")
        c = ref['classification_counts'][name]
        print(f"  Table 3 row: images {lk['pool_after_exclusion_images']:,} "
              f"({lk['released_images']:,})   train+val {c['train'] + c['val']:,}   "
              f"test {c['test']:,}")
    print('\nIf any figure above differs from the manuscript, the manuscript is '
          'what must change.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
