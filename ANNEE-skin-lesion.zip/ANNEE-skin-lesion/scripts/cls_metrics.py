#!/usr/bin/env python3
"""Recompute Tables 4, 5, 7 and the classification rows of Table 10.

This is the script Section 3.12 names for "the classification tables from the
released prediction files". It reads predictions.csv only; no model is loaded
and nothing is retrained.

Usage
    # Table 4 and the Table 5 audit for one run
    python scripts/cls_metrics.py \
        --predictions artifacts/predictions/A_isic2019_seed0/classification/predictions.csv \
        --out artifacts/tables/table4_isic2019.json

    # McNemar against the full model, the "p vs (A)" column of Table 7
    python scripts/cls_metrics.py \
        --predictions artifacts/predictions/B_isic2019_seed0/classification/predictions.csv \
        --compare-with artifacts/predictions/A_isic2019_seed0/classification/predictions.csv

    # mean +- sd across the five seeds
    python scripts/cls_metrics.py --predictions \
        artifacts/predictions/A_isic2019_seed{0,1,2,3,4}/classification/predictions.csv \
        --aggregate
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from annee.metrics import classification_report
from annee.predict import load_classification_predictions
from annee.stats import mcnemar, delong, accuracy_ci


def evaluate(path: Path) -> dict:
    y, prob, ids = load_classification_predictions(path)
    manifest_path = path.parent / 'manifest.json'
    manifest = json.loads(manifest_path.read_text()) if manifest_path.exists() else {}
    rep = classification_report(y, prob, prob.shape[1])
    rep['run'] = path.parent.parent.name
    rep['variant'] = manifest.get('variant')
    rep['checkpoint_stage'] = manifest.get('checkpoint_stage')
    rep['archive'] = manifest.get('archive')
    rep['class_names'] = manifest.get('class_names')
    rep['accuracy_ci'] = accuracy_ci(prob.argmax(1) == y)
    rep['_y'] = y
    rep['_prob'] = prob
    rep['_ids'] = ids
    return rep


def _print_table4(rep: dict):
    names = rep['class_names'] or [str(i) for i in range(len(rep['per_class']['f1']))]
    pc = rep['per_class']
    audit = rep['audit']
    print(f"\n{rep['run']}  variant={rep['variant']}  archive={rep['archive']}")
    print(f"{'class':<10}{'support':>8}{'pred':>7}{'correct':>9}"
          f"{'acc%':>8}{'prec%':>8}{'rec%':>8}{'F1%':>8}{'AUC%':>8}")
    for i, n in enumerate(names):
        print(f'{n:<10}{audit["support"][i]:>8}{audit["predicted"][i]:>7}'
              f'{audit["correct"][i]:>9}{100*pc["accuracy"][i]:>8.2f}'
              f'{100*pc["precision"][i]:>8.2f}{100*pc["recall"][i]:>8.2f}'
              f'{100*pc["f1"][i]:>8.2f}{100*pc["auc"][i]:>8.2f}')
    ci = rep['accuracy_ci']
    print(f'overall accuracy {100*rep["overall_accuracy"]:.2f}% '
          f'(95% CI {100*ci["ci_low"]:.2f}-{100*ci["ci_high"]:.2f}), '
          f'macro F1 {100*rep["macro_f1"]:.2f}%, macro AUC {100*rep["macro_auc"]:.2f}%')
    print(f'audit: {audit["diagonal_sum"]}/{audit["total"]} = '
          f'{100*audit["overall_accuracy"]:.2f}%  (Table 5)')


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--predictions', nargs='+', required=True)
    ap.add_argument('--compare-with', default=None,
                    help='reference run for McNemar and DeLong (variant A)')
    ap.add_argument('--aggregate', action='store_true')
    ap.add_argument('--out', default=None)
    args = ap.parse_args(argv)

    reports = [evaluate(Path(p)) for p in args.predictions]
    for r in reports:
        _print_table4(r)

    out = {'runs': [{k: v for k, v in r.items() if not k.startswith('_')}
                    for r in reports]}

    if args.compare_with:
        ref = evaluate(Path(args.compare_with))
        out['comparisons'] = []
        for r in reports:
            if r['_ids'] != ref['_ids']:
                raise SystemExit('McNemar needs the identical test set in the '
                                 'identical order; the two runs differ')
            mc = mcnemar(ref['_prob'].argmax(1) == ref['_y'],
                         r['_prob'].argmax(1) == r['_y'])
            # DeLong on the positive class of the binary one-vs-rest problem
            # with the largest support, as a representative AUC comparison
            k = int(np.bincount(ref['_y'], minlength=ref['_prob'].shape[1]).argmax())
            dl = delong(ref['_y'] == k, ref['_prob'][:, k], r['_prob'][:, k])
            print(f"\n{r['run']} vs {ref['run']}: McNemar p = {mc['p_value']:.4f} "
                  f"({mc['method']}, n01={mc['n01']}, n10={mc['n10']}); "
                  f"DeLong p = {dl['p_value']:.4f}")
            out['comparisons'].append({'run': r['run'], 'reference': ref['run'],
                                       'mcnemar': mc, 'delong': dl})

    if args.aggregate and len(reports) > 1:
        keys = ('overall_accuracy', 'macro_f1', 'macro_auc')
        agg = {}
        for k in keys:
            v = np.array([r[k] for r in reports], float)
            agg[k] = {'mean': float(v.mean()),
                      'sd': float(v.std(ddof=1)) if len(v) > 1 else 0.0,
                      'median': float(np.median(v))}
        out['aggregate'] = agg
        print('\nacross %d seeds (Table 7 reports the median seed '
              '+- this sd):' % len(reports))
        for k in keys:
            print(f'   {k:<18} mean {100*agg[k]["mean"]:.1f}  '
                  f'sd {100*agg[k]["sd"]:.1f}  median {100*agg[k]["median"]:.1f}')

    if args.out:
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.out).write_text(json.dumps(out, indent=2), encoding='utf-8')
        print(f'\nwrote {args.out}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
