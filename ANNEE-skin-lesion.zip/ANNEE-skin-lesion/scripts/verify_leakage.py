#!/usr/bin/env python3
"""Verify both leakage-control rules against the realised split assignments.

This is the check Section 3.11.1 reports:

    "We verified it on the realised split assignments rather than on the
    intended protocol: for each of the five seeds, the intersection between
    the ISIC 2018 Task 1 validation and test lesion sets and the union of the
    ISIC 2019 and HAM10000 training and validation lesion sets is empty, and
    the same holds at image level after expanding every lesion to all of its
    acquisitions."

It reads the released split index files, so a reader can repeat it without
the images and without retraining. Exit status is non-zero on any violation,
which makes it usable as a CI gate.

    python scripts/verify_leakage.py --splits artifacts/splits
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from annee.splits import SplitResult, verify_leakage


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--splits', default='artifacts/splits')
    ap.add_argument('--out', default=None)
    args = ap.parse_args(argv)

    root = Path(args.splits)
    index_files = sorted(root.glob('seed*/split_index.json'))
    if not index_files:
        raise SystemExit(f'no split index files under {root}')

    reports, failed = [], False
    for p in index_files:
        blob = json.loads(p.read_text())
        result = SplitResult(seed=blob['seed'],
                             segmentation=blob['segmentation'],
                             classification=blob['classification'],
                             leakage=blob.get('leakage', {}))
        try:
            report = verify_leakage(result)
            print(f'seed {result.seed}: PASS')
            for name, c in report['checks'].items():
                print(f'    {name}: rule (i) overlap 0, rule (ii) overlap 0')
        except AssertionError as exc:
            failed = True
            report = {'seed': result.seed, 'passed': False, 'error': str(exc)}
            print(f'seed {result.seed}: FAIL - {exc}', file=sys.stderr)
        reports.append(report)

    if args.out:
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.out).write_text(json.dumps(reports, indent=2), encoding='utf-8')

    if failed:
        print('\nLEAKAGE CHECK FAILED. The manuscript claims these '
              'intersections are empty; fix the splits or the claim.',
              file=sys.stderr)
        return 1
    print(f'\nAll {len(reports)} seeds pass both rules.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
