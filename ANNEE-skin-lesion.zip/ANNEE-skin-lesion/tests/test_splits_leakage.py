"""Both leakage-control rules of Section 3.11.1 must hold on realised splits.

The fixture builds a small synthetic set of archives with a deliberate
overlap between the segmentation benchmark and the classification archives,
including lesions with several acquisitions, and then checks that:

  * rule (i)  keeps Stage-1 training lesions out of classification val/test;
  * rule (ii) removes ISIC 2018 validation and test lesions from the
              classification archives altogether;
  * grouping never splits a lesion across subsets;
  * the counts the manuscript quotes are the ones the code produces.
"""
import numpy as np
import pandas as pd
import pytest

from annee.splits import (Archive, build_splits, verify_leakage, match_lesions,
                          stratified_group_split)


def _make_archives(n_seg=120, n_cls=400, overlap=60, seed=0):
    rng = np.random.default_rng(seed)

    seg = pd.DataFrame({
        'image_id': [f'SEG{i:04d}' for i in range(n_seg)],
        'lesion_id': [f'LES{i:04d}' for i in range(n_seg)],
        'isic_id': [f'ISIC{i:06d}' for i in range(n_seg)],
    })

    rows = []
    # the first `overlap` segmentation lesions also appear in the archive,
    # some of them with a second acquisition
    for i in range(overlap):
        rows.append({'image_id': f'CLS{i:04d}', 'lesion_id': f'LES{i:04d}',
                     'isic_id': f'ISIC{i:06d}',
                     'label': ['nv', 'mel', 'bcc'][i % 3]})
        if i % 3 == 0:
            rows.append({'image_id': f'CLS{i:04d}b', 'lesion_id': f'LES{i:04d}',
                         'isic_id': '', 'label': ['nv', 'mel', 'bcc'][i % 3]})
    for j in range(overlap, n_cls):
        lesion = f'XLES{j:04d}'
        rows.append({'image_id': f'CLS{j:04d}', 'lesion_id': lesion,
                     'isic_id': f'XISIC{j:06d}',
                     'label': ['nv', 'mel', 'bcc'][int(rng.integers(3))]})
    cls = pd.DataFrame(rows)
    return Archive('isic2018', seg), {'isic2019': Archive('isic2019', cls)}


@pytest.fixture(scope='module')
def built():
    seg, cls = _make_archives()
    return seg, cls, build_splits(seg, cls, seed=0)


def test_matching_finds_the_overlap(built):
    seg, cls, _ = built
    matched = match_lesions(seg, cls['isic2019'])
    assert len(matched) == 60


def test_rule_ii_excludes_heldout_segmentation_lesions(built):
    _, _, result = built
    held = set(result.segmentation['lesions']['val']) | \
        set(result.segmentation['lesions']['test'])
    present = set().union(*(set(v) for v in
                            result.classification['isic2019']['lesions'].values()))
    assert not (held & present), (
        'a held-out ISIC 2018 lesion survived in the classification archive')


def test_rule_i_forces_stage1_training_lesions_into_train(built):
    _, _, result = built
    train_seg = set(result.segmentation['lesions']['train'])
    block = result.classification['isic2019']['lesions']
    assert not (train_seg & set(block['val']))
    assert not (train_seg & set(block['test']))


def test_verify_leakage_passes(built):
    _, _, result = built
    report = verify_leakage(result)
    assert report['passed']


def test_verify_leakage_detects_an_injected_violation(built):
    """The checker must actually fail when a rule is broken."""
    import copy
    _, _, result = built
    broken = copy.deepcopy(result)
    poisoned = result.segmentation['lesions']['test'][0]
    broken.classification['isic2019']['lesions']['train'].append(poisoned)
    with pytest.raises(AssertionError):
        verify_leakage(broken)


def test_lesions_are_never_split_across_subsets(built):
    _, _, result = built
    block = result.classification['isic2019']['lesions']
    a, b, c = (set(block[k]) for k in ('train', 'val', 'test'))
    assert not (a & b) and not (a & c) and not (b & c)


def test_counts_are_consistent(built):
    _, _, result = built
    block = result.classification['isic2019']
    lk = result.leakage['isic2019']
    total = sum(block['counts'].values())
    assert total == block['pool_images']
    assert (lk['released_images'] - lk['rule_ii_excluded_images']
            == lk['pool_after_exclusion_images'])


def test_grouping_keeps_all_acquisitions_together():
    frame = pd.DataFrame({
        'image_id': [f'I{i}' for i in range(12)],
        'lesion_id': ['A'] * 4 + ['B'] * 4 + ['C'] * 4,
        'label': ['x'] * 12,
    })
    split = stratified_group_split(frame, seed=0)
    allocated = [set(v) for v in split.values()]
    for lesion in ('A', 'B', 'C'):
        assert sum(lesion in s for s in allocated) == 1


def test_split_is_deterministic_for_a_seed():
    seg, cls = _make_archives()
    a = build_splits(seg, cls, seed=3)
    b = build_splits(seg, cls, seed=3)
    assert a.classification['isic2019']['images'] == \
        b.classification['isic2019']['images']


def test_different_seeds_give_different_partitions():
    seg, cls = _make_archives()
    a = build_splits(seg, cls, seed=0)
    b = build_splits(seg, cls, seed=1)
    assert a.classification['isic2019']['images']['test'] != \
        b.classification['isic2019']['images']['test']
