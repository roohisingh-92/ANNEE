"""Preprocessing, supervision targets and the inference path.

Two things are checked that the manuscript asserts in prose:

  * the TensorFlow and NumPy preprocessing paths agree, so the training graph
    and the offline dataset preparation cannot drift apart;
  * E_true has the stated band thickness t = 2*rho, and the morphology of
    Section 3.7 acts on the binarised **region** map, not on the boundary map.
"""
import numpy as np
import tensorflow as tf
import pytest

from annee import preprocessing as P
from annee.postprocess import (inference_mask, boundary_confidence,
                               soft_confidence, classifier_input_soft,
                               classifier_input_hard, otsu_threshold)

SIZE = 64


def _image(seed=0):
    rng = np.random.default_rng(seed)
    img = rng.random((80, 96, 3)).astype(np.float32)
    img[20:50, 25:70] += 0.6                     # a bright blob with edges
    return np.clip(img, 0, 1)


def _disc(size=SIZE, r=18):
    yy, xx = np.mgrid[:size, :size]
    c = size // 2
    return (((yy - c) ** 2 + (xx - c) ** 2) <= r * r).astype(np.float32)


# ---------------------------------------------------------------- pipeline
def test_normalisation_maps_to_unit_range():
    out = P.np_minmax(_image())
    assert out.min() == pytest.approx(0.0, abs=1e-6)
    assert out.max() == pytest.approx(1.0, abs=1e-6)


def test_edge_map_is_rescaled_by_its_per_image_maximum():
    _, e0 = P.np_preprocess(_image(), SIZE)
    assert e0.max() == pytest.approx(1.0, abs=1e-5)
    assert e0.min() >= 0.0


def test_luma_uses_bt601_weights():
    img = np.zeros((4, 4, 3), np.float32)
    img[..., 1] = 1.0
    assert P.np_luma(img)[0, 0] == pytest.approx(0.587, abs=1e-6)


def test_mask_resize_stays_binary():
    m = _disc(100, 30)
    out = P.np_resize_mask(m, SIZE)
    assert set(np.unique(out)) <= {0.0, 1.0}


def test_tf_and_numpy_preprocessing_agree():
    """The training graph and the offline preparation must not drift apart."""
    img = _image(3)
    i_np, e_np = P.np_preprocess(img, SIZE)
    i_tf, e_tf = P.tf_preprocess(tf.constant(img[None]), SIZE)
    i_tf, e_tf = np.asarray(i_tf)[0], np.asarray(e_tf)[0, ..., 0]
    assert np.abs(i_np - i_tf).mean() < 2e-2
    assert np.corrcoef(e_np.ravel(), e_tf.ravel())[0, 1] > 0.97


# ------------------------------------------------------------- E_true, 3.2.7
def test_boundary_target_band_thickness_is_two_rho():
    """Section 3.2.7: t = 2*rho px; rho = 1 gives the thinnest closed contour."""
    m = _disc(128, 40)
    for rho in (1, 2, 3):
        band = P.np_boundary_target(m, rho)
        # measure the band across a horizontal cut through the centre
        row = band[64]
        runs, run = [], 0
        for v in row:
            if v > 0.5:
                run += 1
            elif run:
                runs.append(run)
                run = 0
        if run:
            runs.append(run)
        assert runs, 'no band found'
        assert max(runs) == pytest.approx(2 * rho, abs=1)


def test_boundary_target_is_binary_and_closed():
    m = _disc(64, 20)
    e = P.np_boundary_target(m, 1)
    assert set(np.unique(e)) <= {0.0, 1.0}
    assert e.sum() > 0
    # the contour encloses the lesion: filling it recovers (roughly) the mask
    from scipy import ndimage
    filled = ndimage.binary_fill_holes(e > 0.5)
    assert filled.sum() >= m.sum() * 0.9


def test_boundary_target_of_an_empty_mask_is_empty():
    assert P.np_boundary_target(np.zeros((32, 32), np.float32)).sum() == 0


# ------------------------------------------------------- inference path, 3.7
def test_inference_mask_keeps_only_the_largest_component():
    r = np.zeros((SIZE, SIZE), np.float32)
    r[_disc(SIZE, 18) > 0.5] = 0.9      # the lesion
    r[2:6, 2:6] = 0.85                  # a spurious fragment, must be dropped
    m = inference_mask(r, use_morphology=True)
    assert m.sum() > 0.8 * _disc(SIZE, 18).sum()
    assert m[2:6, 2:6].sum() == 0


def test_inference_mask_fills_holes():
    r = np.zeros((SIZE, SIZE), np.float32)
    r[10:40, 10:40] = 0.9
    r[20:25, 20:25] = 0.0           # a hole
    m = inference_mask(r, use_morphology=True)
    assert m[20:25, 20:25].mean() == pytest.approx(1.0)


def test_morphology_can_be_switched_off_variant_f():
    r = np.zeros((SIZE, SIZE), np.float32)
    r[10:40, 10:40] = 0.9
    r[20:25, 20:25] = 0.0
    m = inference_mask(r, use_morphology=False)
    assert m[20:25, 20:25].sum() == 0, 'variant (F) must leave the hole'


def test_otsu_is_computed_per_image():
    a = np.concatenate([np.full(500, 0.1), np.full(500, 0.9)]).astype(np.float32)
    assert 0.1 < otsu_threshold(a) < 0.9


def test_boundary_confidence_averages_over_the_contour():
    m = _disc(SIZE, 15)
    e = np.zeros((SIZE, SIZE), np.float32)
    from scipy import ndimage
    contour = (m > 0.5) & ~ndimage.binary_erosion(m > 0.5, np.ones((3, 3), bool))
    e[contour] = 0.75
    assert boundary_confidence(e, m) == pytest.approx(0.75, abs=1e-5)


def test_soft_confidence_approaches_hard_confidence_for_binary_maps():
    """c_soft -> c as E_hat approaches a binary boundary indicator."""
    e = np.zeros((1, SIZE, SIZE, 1), np.float32)
    e[0, 30, 10:50, 0] = 1.0
    c_soft = float(soft_confidence(tf.constant(e))[0])
    assert c_soft == pytest.approx(1.0, abs=1e-4)


def test_soft_confidence_is_differentiable():
    e = tf.Variable(np.random.default_rng(0).random((1, 16, 16, 1)).astype('float32'))
    with tf.GradientTape() as tape:
        c = soft_confidence(e)
    assert tape.gradient(c, e) is not None


def test_classifier_inputs_have_five_channels():
    i = tf.constant(np.random.default_rng(0).random((2, 16, 16, 3)).astype('float32'))
    r = tf.constant(np.random.default_rng(1).random((2, 16, 16, 1)).astype('float32'))
    e = tf.constant(np.random.default_rng(2).random((2, 16, 16, 1)).astype('float32'))
    assert classifier_input_soft(i, r, e).shape[-1] == 5
    hard = classifier_input_hard(np.asarray(i)[0], _disc(16, 5), np.asarray(e)[0])
    assert hard.shape[-1] == 5


def test_training_path_never_thresholds():
    """Section 3.6: M_soft = R_hat, unthresholded, so gradients flow."""
    i = tf.Variable(np.random.default_rng(0).random((1, 16, 16, 3)).astype('float32'))
    r = tf.Variable(np.random.default_rng(1).random((1, 16, 16, 1)).astype('float32'))
    e = tf.Variable(np.random.default_rng(2).random((1, 16, 16, 1)).astype('float32'))
    with tf.GradientTape() as tape:
        x = classifier_input_soft(i, r, e)
        loss = tf.reduce_sum(x)
    g_r, g_e = tape.gradient(loss, [r, e])
    assert g_r is not None and g_e is not None
    assert np.abs(np.asarray(g_r)).sum() > 0
