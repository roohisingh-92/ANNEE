"""The objective must match Eqs. (13), (14) and (15a)-(15c) exactly.

These tests are the executable form of Reviewer 2's second request. If the
manuscript and the code ever drift apart again, one of them fails.
"""
import numpy as np
import tensorflow as tf
import pytest

from annee.losses import (edge_preservation_loss, lesion_loss, soft_dice,
                          binary_cross_entropy, classification_loss,
                          inverse_frequency_weights, UncertaintyWeights,
                          stage2_objective)

H = W = 16


def _rand(shape, seed=0):
    return tf.constant(np.random.default_rng(seed).random(shape), tf.float32)


# ---------------------------------------------------------------- Eq. (13)
def test_edge_loss_is_mean_not_sum():
    """Eq. (13) carries the 1/|Omega| factor; the first submission did not."""
    e_hat = tf.ones((2, H, W, 1))
    e0 = tf.zeros((2, H, W, 1))
    loss = edge_preservation_loss(e_hat, e0)
    assert np.allclose(loss.numpy(), 1.0), 'mean reduction expected, got a sum'
    # the unnormalised sum would be |Omega| times larger
    assert not np.allclose(loss.numpy(), H * W)


def test_edge_loss_is_zero_on_agreement():
    e = _rand((3, H, W, 1))
    assert np.allclose(edge_preservation_loss(e, e).numpy(), 0.0, atol=1e-6)


def test_edge_loss_needs_no_ground_truth():
    """L_edge compares E_hat with E_0, both available without expert masks."""
    import inspect
    params = inspect.signature(edge_preservation_loss).parameters
    assert set(params) == {'e_hat', 'e0'}


# ---------------------------------------------------------------- Eq. (14)
def test_lesion_loss_contains_region_and_boundary_terms():
    """The region component must be present: Dice + BCE on R_hat."""
    rng = np.random.default_rng(1)
    m = tf.constant((rng.random((2, H, W, 1)) > 0.5).astype('float32'))
    e_true = tf.constant((rng.random((2, H, W, 1)) > 0.8).astype('float32'))
    r_hat, e_hat = _rand((2, H, W, 1), 2), _rand((2, H, W, 1), 3)

    total = lesion_loss(r_hat, e_hat, m, e_true).numpy()
    region = ((1.0 - soft_dice(r_hat, m)) + binary_cross_entropy(r_hat, m)).numpy()
    boundary = tf.reduce_mean(tf.abs(e_hat - e_true), axis=[1, 2, 3]).numpy()
    assert np.allclose(total, region + boundary, atol=1e-5)
    assert np.all(region > 0), 'region term must contribute'


def test_lesion_loss_boundary_term_uses_same_reduction_as_eq13():
    rng = np.random.default_rng(4)
    m = tf.constant((rng.random((1, H, W, 1)) > 0.5).astype('float32'))
    e_hat = tf.ones((1, H, W, 1))
    e_true = tf.zeros((1, H, W, 1))
    boundary = (lesion_loss(e_hat * 0 + 0.5, e_hat, m, e_true) -
                ((1.0 - soft_dice(e_hat * 0 + 0.5, m)) +
                 binary_cross_entropy(e_hat * 0 + 0.5, m))).numpy()
    assert np.allclose(boundary, 1.0, atol=1e-5)


def test_perfect_prediction_minimises_lesion_loss():
    rng = np.random.default_rng(5)
    m = tf.constant((rng.random((1, H, W, 1)) > 0.5).astype('float32'))
    e_true = tf.constant((rng.random((1, H, W, 1)) > 0.8).astype('float32'))
    good = lesion_loss(m, e_true, m, e_true).numpy()
    bad = lesion_loss(1 - m, 1 - e_true, m, e_true).numpy()
    assert good < bad


# ------------------------------------------------- Eqs. (15a), (15b), (15c)
def test_stage1_objective_matches_equation_15a():
    w = UncertaintyWeights()
    l_e = tf.constant(0.4)
    l_l = tf.constant(0.9)
    s_e, s_l = float(w.s_e.numpy()), float(w.s_l.numpy())
    expected = np.exp(-s_e) * 0.4 + s_e + np.exp(-s_l) * 0.9 + s_l
    assert np.allclose(w.stage1_objective(l_e, l_l).numpy(), expected, atol=1e-6)


def test_stage2_objective_is_classification_loss_alone():
    l = tf.constant(1.23)
    assert float(stage2_objective(l)) == pytest.approx(1.23)


def test_stage3_objective_matches_equation_15c_and_drops_lesion_term():
    w = UncertaintyWeights()
    s_e = float(w.s_e.numpy())
    got = w.stage3_objective(tf.constant(0.4), tf.constant(2.0), lam=1.0).numpy()
    expected = np.exp(-s_e) * 0.4 + s_e + 1.0 * 2.0
    assert np.allclose(got, expected, atol=1e-6)
    # s_l plays no part in Stage 3
    import inspect
    assert 'l_lesion' not in inspect.signature(w.stage3_objective).parameters


def test_log_variances_start_at_zero_and_shares_at_one_half():
    """Section 3.5: both initialised at zero, so the shares start at 0.5."""
    w = UncertaintyWeights()
    assert float(w.s_e.numpy()) == 0.0 and float(w.s_l.numpy()) == 0.0
    a, b = w.normalised_shares()
    assert float(a) == pytest.approx(0.5) and float(b) == pytest.approx(0.5)


def test_raw_coefficients_are_not_the_reported_shares():
    """The distinction the reviewer asked to be made explicit."""
    w = UncertaintyWeights()
    w.s_e.assign(0.8)       # exp(-0.8) = 0.449
    w.s_l.assign(-0.1)      # exp(+0.1) = 1.105
    raw_a, raw_b = float(w.alpha_raw), float(w.beta_raw)
    a_n, b_n = (float(x) for x in w.normalised_shares())
    assert raw_a == pytest.approx(np.exp(-0.8), rel=1e-5)
    assert raw_b == pytest.approx(np.exp(0.1), rel=1e-5)
    assert a_n + b_n == pytest.approx(1.0)           # shares sum to one
    assert raw_a + raw_b != pytest.approx(1.0)       # raw coefficients do not
    assert a_n == pytest.approx(raw_a / (raw_a + raw_b), rel=1e-6)


def test_no_constraint_is_applied_to_the_log_variances():
    """They are unconstrained scalars; nothing clips or normalises them."""
    w = UncertaintyWeights()
    w.s_e.assign(-5.0)
    assert float(w.s_e.numpy()) == -5.0
    w.s_e.assign(12.0)
    assert float(w.s_e.numpy()) == 12.0


def test_fixed_weight_variants_drop_the_log_variance_terms():
    """Variants (J)-(L): L = alpha*L_edge + beta*L_lesion, no s terms."""
    w = UncertaintyWeights(fixed=(0.3, 0.7))
    got = w.stage1_objective(tf.constant(2.0), tf.constant(4.0)).numpy()
    assert np.allclose(got, 0.3 * 2.0 + 0.7 * 4.0)
    assert w.trainable_variables == ()
    got3 = w.stage3_objective(tf.constant(2.0), tf.constant(1.0), lam=1.0).numpy()
    assert np.allclose(got3, 0.3 * 2.0 + 1.0)


def test_log_variances_are_trainable_in_the_adaptive_scheme():
    w = UncertaintyWeights()
    assert len(w.trainable_variables) == 2
    with tf.GradientTape() as tape:
        loss = w.stage1_objective(tf.constant(0.5), tf.constant(0.5))
    grads = tape.gradient(loss, list(w.trainable_variables))
    assert all(g is not None for g in grads)


# ------------------------------------------------- Eq. (23) and Section 3.12
def test_inverse_frequency_weights_satisfy_the_stated_identity():
    """Section 3.12: sum_k n_k w_k = N for w_k = N / (K n_k)."""
    counts = np.array([100, 50, 25, 25], np.float32)
    w = inverse_frequency_weights(counts).numpy()
    assert np.allclose((counts * w).sum(), counts.sum(), rtol=1e-5)
    assert np.allclose(w, counts.sum() / (len(counts) * counts), rtol=1e-5)


def test_classification_loss_applies_the_class_weights():
    y = tf.constant([[0., 1., 0.]])
    p = tf.constant([[0.1, 0.7, 0.2]])
    w = tf.constant([1.0, 3.0, 1.0])
    unweighted = float(classification_loss(y, p)[0])
    weighted = float(classification_loss(y, p, w)[0])
    assert weighted == pytest.approx(3.0 * unweighted, rel=1e-5)


def test_unit_weights_recover_the_unweighted_cross_entropy():
    y = tf.constant([[0., 1., 0.]])
    p = tf.constant([[0.1, 0.7, 0.2]])
    ones = tf.ones([3])
    assert float(classification_loss(y, p, ones)[0]) == pytest.approx(
        float(classification_loss(y, p)[0]), rel=1e-6)
