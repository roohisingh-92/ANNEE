"""Metrics and significance tests.

The Table 5 audit is the reviewer's own earlier point: every count-based
entry of Table 4 must be recomputable from the confusion matrix. That is
asserted here rather than claimed.
"""
import numpy as np
import pytest

from annee.metrics import (dice, iou, sensitivity, specificity,
                           boundary_f_score, hausdorff_percentile,
                           confusion_matrix, audit_confusion,
                           per_class_metrics, classification_report)
from annee.stats import mcnemar, delong, bootstrap_ci, accuracy_ci


def _disc(size=64, r=18, dx=0, dy=0):
    yy, xx = np.mgrid[:size, :size]
    c = size // 2
    return (((yy - c - dy) ** 2 + (xx - c - dx) ** 2) <= r * r).astype(np.float32)


# ---------------------------------------------------------------- segmentation
def test_identical_masks_are_perfect():
    m = _disc()
    assert dice(m, m) == pytest.approx(1.0)
    assert iou(m, m) == pytest.approx(1.0)
    assert sensitivity(m, m) == pytest.approx(1.0)
    assert specificity(m, m) == pytest.approx(1.0)
    assert boundary_f_score(m, m) == pytest.approx(1.0)
    assert hausdorff_percentile(m, m) == pytest.approx(0.0)


def test_disjoint_masks_score_zero():
    a = np.zeros((64, 64), np.float32); a[:10, :10] = 1
    b = np.zeros((64, 64), np.float32); b[50:, 50:] = 1
    assert dice(a, b) == 0.0
    assert iou(a, b) == 0.0


def test_dice_and_iou_are_consistent():
    """IoU = Dice / (2 - Dice) for any pair of binary masks."""
    a, b = _disc(), _disc(dx=6)
    d, j = dice(a, b), iou(a, b)
    assert j == pytest.approx(d / (2 - d), rel=1e-6)


def test_metrics_degrade_monotonically_with_displacement():
    true = _disc()
    scores = [dice(_disc(dx=k), true) for k in (0, 3, 6, 12)]
    assert scores == sorted(scores, reverse=True)
    hd = [hausdorff_percentile(_disc(dx=k), true) for k in (0, 3, 6, 12)]
    assert hd == sorted(hd)


def test_boundary_f_respects_the_two_pixel_tolerance():
    true = _disc(r=20)
    near = _disc(r=21)      # within tolerance
    far = _disc(r=28)       # well outside it
    assert boundary_f_score(near, true) > 0.9
    assert boundary_f_score(far, true) < 0.5


def test_hd95_ignores_a_single_outlier():
    true = _disc()
    pred = true.copy()
    pred[0, 0] = 1.0        # one distant stray pixel
    assert hausdorff_percentile(pred, true) < 10.0


# ------------------------------------------------------------- classification
def test_audit_reproduces_table5_identities():
    rng = np.random.default_rng(0)
    y = rng.integers(0, 4, 200)
    p = np.where(rng.random(200) < 0.8, y, rng.integers(0, 4, 200))
    cm = confusion_matrix(y, p, 4)
    a = audit_confusion(cm)
    assert sum(a['support']) == a['total'] == 200
    assert sum(a['predicted']) == a['total']
    assert sum(a['correct']) == a['diagonal_sum']
    assert a['overall_accuracy'] == pytest.approx(a['diagonal_sum'] / a['total'])


def test_per_class_metrics_are_recomputable_from_the_matrix():
    cm = np.array([[50, 5, 0], [3, 40, 2], [1, 4, 25]])
    pc = per_class_metrics(cm)
    tp = cm[0, 0]; fp = cm[:, 0].sum() - tp; fn = cm[0, :].sum() - tp
    assert pc['precision'][0] == pytest.approx(tp / (tp + fp))
    assert pc['recall'][0] == pytest.approx(tp / (tp + fn))
    assert pc['f1'][0] == pytest.approx(
        2 * pc['precision'][0] * pc['recall'][0] /
        (pc['precision'][0] + pc['recall'][0]))


def test_classification_report_macro_averages_weight_classes_equally():
    rng = np.random.default_rng(1)
    y = rng.integers(0, 3, 300)
    prob = rng.random((300, 3))
    prob[np.arange(300), y] += 1.5
    prob /= prob.sum(1, keepdims=True)
    rep = classification_report(y, prob, 3)
    assert rep['macro_f1'] == pytest.approx(np.mean(rep['per_class']['f1']))
    assert rep['macro_auc'] == pytest.approx(np.nanmean(rep['per_class']['auc']))
    assert 0.5 < rep['overall_accuracy'] <= 1.0


# ------------------------------------------------------------------ statistics
def test_mcnemar_is_one_on_identical_predictions():
    c = np.array([True, False, True, True])
    assert mcnemar(c, c)['p_value'] == 1.0


def test_mcnemar_detects_a_consistent_difference():
    n = 400
    a = np.ones(n, bool)
    b = np.ones(n, bool)
    b[:40] = False                     # B is wrong where A is right
    r = mcnemar(a, b)
    assert r['n01'] == 40 and r['n10'] == 0
    assert r['p_value'] < 0.01


def test_mcnemar_uses_the_exact_test_for_few_discordant_pairs():
    a = np.ones(100, bool); b = np.ones(100, bool); b[:5] = False
    assert mcnemar(a, b)['method'] == 'exact binomial'


def test_mcnemar_rejects_mismatched_test_sets():
    with pytest.raises(ValueError):
        mcnemar(np.ones(10, bool), np.ones(11, bool))


def test_delong_recovers_a_known_auc():
    rng = np.random.default_rng(0)
    y = np.r_[np.ones(200), np.zeros(200)].astype(bool)
    s = np.r_[rng.normal(1, 1, 200), rng.normal(0, 1, 200)]
    from sklearn.metrics import roc_auc_score
    r = delong(y, s, s)
    assert r['auc_a'] == pytest.approx(roc_auc_score(y, s), abs=1e-6)
    assert r['p_value'] == 1.0          # a score against itself


def test_delong_separates_a_strong_from_a_weak_score():
    rng = np.random.default_rng(2)
    y = np.r_[np.ones(300), np.zeros(300)].astype(bool)
    strong = np.r_[rng.normal(2, 1, 300), rng.normal(0, 1, 300)]
    weak = np.r_[rng.normal(0.2, 1, 300), rng.normal(0, 1, 300)]
    r = delong(y, strong, weak)
    assert r['auc_a'] > r['auc_b']
    assert r['p_value'] < 0.01


def test_bootstrap_interval_brackets_the_estimate():
    rng = np.random.default_rng(3)
    v = rng.normal(0.95, 0.02, 500)
    ci = bootstrap_ci(v, seed=1)
    assert ci['ci_low'] <= ci['estimate'] <= ci['ci_high']
    assert ci['resamples'] == 1000


def test_accuracy_ci_is_reproducible_for_a_seed():
    c = np.random.default_rng(4).random(500) < 0.96
    assert accuracy_ci(c, seed=7) == accuracy_ci(c, seed=7)
