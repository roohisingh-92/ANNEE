# Known discrepancies between the manuscript and this code

Things the code says that the current manuscript text does not, found while
building the repository. Each needs a decision before submission. Nothing here
is silently "fixed" in the code to match the paper; where the two disagree the
code states what it computes and this file records the conflict.

---

## 1. Table 10, baseline GMAC column — **the manuscript is wrong**

Severity: high. This is the column Reviewer 2 asked to have verified.

Section 4.2 now states that the MAC counts "were recomputed for every entry
with the same counting script rather than copied from the original papers".
Running `scripts/count_macs.py --baselines` gives figures that disagree with
the table for the three classification backbones, and the disagreement is
systematic — roughly a factor of two, in the direction of a MAC/FLOP
confusion.

| Model | Table 10 | `count_macs.py` at 256×256 | Published value, rescaled |
|---|---|---|---|
| ResNet-50 | 2.68 GMAC | **5.04** | 4.1 GMAC @224 → 5.4 @256 |
| EfficientNet-B3 | 0.66 GMAC | **1.25** | 1.8 GMAC @300 → 1.31 @256 |
| ConvNeXt-T | 2.94 GMAC | **5.82** | 4.5 GMAC @224 → 5.9 @256 |

The counter agrees with the published references to within a few per cent in
all three cases; the table does not. The most likely origin is that the
original-paper numbers — which are MACs, although those papers label them
"FLOPs" — were divided by two on the assumption that they were FLOPs.

The parameter column has a smaller, separate inconsistency: 25.6 M / 12.2 M /
28.6 M are the counts *including* the original 1000-class ImageNet head.
With the 8-class head actually used here they are 23.55 M / 10.71 M / 27.83 M.
Either convention is defensible; it just has to be stated and applied to
ANNEE too.

### What this changes in the text

The arithmetic comparison in Section 4.2 does not survive. Against recomputed
figures the complete ANNEE pipeline (12.86 GMAC) is about **2.6×** ResNet-50,
**2.2×** ConvNeXt-T and **10.3×** EfficientNet-B3 — not "four to five times"
and not the "4.8× / 4.4× / nineteen times" that followed from the printed
table. The qualitative conclusion is unchanged and in fact becomes milder:
ANNEE is smaller in parameters and more expensive in arithmetic, but by a
factor of two to three against the heavier backbones rather than four to five.

### What to do

Run the counter over **your own** baseline implementations, not the ones in
`annee/baselines.py`, which are faithful-in-spirit reconstructions rather
than the exact configurations you trained. Then update the GMAC column, the
parameter column convention, and the ratio sentence in Section 4.2.

The four segmentation baselines are reconstructions too, and their figures
(Attention U-Net 21.95 M / 53.27 GMAC, U-Net++ 30.89 M / 52.03, DeepLabv3+
17.79 M / 11.40, TransUNet 99.41 M / 23.53) will not match yours exactly.
Use yours.

---

## 2. Section 3.9, "47% of the parameters" — consistent, worth a word

`scripts/count_macs.py` confirms the bottleneck is 47.4% of the **pipeline**
parameters and 7.3% of the pipeline MACs, so both percentages share a
denominator and the sentence is correct. It reads as though the denominator
might be the segmentation network alone, where the figure would be 50.4%.
A reader checking the arithmetic will try the wrong denominator first.
Consider "47% of the pipeline's parameters".

---

## 3. Counts in Section 3.11.1 and Table 3 — must be regenerated

The figures currently in the text (1,912 / 1,468 matched lesions; 1,531 /
1,174 under rule (i); 381 / 294 under rule (ii); pools of 24,919 and 9,697)
are internally consistent and consistent with Table 3, but they have not been
produced from the archives by this code. `scripts/make_splits.py` prints every
one of them. Run it and reconcile. See `docs/REPORTED_NUMBERS.md`.

---

## 4. Items to confirm against your own records

| Claim | Where | How to check |
|---|---|---|
| `s_e`, `s_l` initialised at zero | Section 3.5, `config.S_INIT` | your training script |
| ISIC 2019 is the Stage-3 archive behind Table 9 | Sections 3.11.1, 3.11.2 | your run logs |
| HAM10000 Stage-3 checkpoint differs by less than the seed s.d. | Section 3.11.2 | run `run_experiment.py --dataset ham10000`, then `seg_metrics.py` |
| TensorFlow version and GPU | Section 3.11 | `environment/paper-environment.txt` |
| Dice smoothing constant of 1 | Section 3.3.3, `config.DICE_SMOOTH` | your loss code |
| Otsu on a 256-bin histogram | Section 3.12, `config.OTSU_BINS` | your post-processing |

---

## 5. Equation (8)

The numbering runs (7), (9), (10): there is no Eq. (8). Nothing refers to it,
so it is cosmetic, but a copy-editor will ask.
