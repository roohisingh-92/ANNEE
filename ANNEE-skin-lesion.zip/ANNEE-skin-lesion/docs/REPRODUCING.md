# Reproducing every table

All commands assume the archives are in `data/` and that
`scripts/make_splits.py` has run.

```bash
make install
make test            # 79 unit tests, no data needed
make splits DATA=data
make verify
```

## Table 2 — layer-wise cost

```bash
python scripts/count_macs.py
```
Needs no data. Reproduces the published figures exactly: 7,287,687 parameters
and 11,859.7 MMAC for the segmentation network, 457,800 and 1,000.4 for the
classifier, 7,745,487 and 12,860.1 for the pipeline, 25.7 GFLOPs, decoder
77.2% of MACs, bottleneck 7.3% of MACs and 47% of parameters.

## Tables 4 and 5 — class-wise metrics and the confusion-matrix audit

```bash
python scripts/run_experiment.py --variant A --seed 0 --dataset isic2019
python scripts/cls_metrics.py \
  --predictions artifacts/predictions/A_isic2019_seed0/classification/predictions.csv \
  --out artifacts/tables/table4_isic2019.json
```
Repeat with `--dataset ham10000`. The audit identities of Table 5 are printed
alongside, so the two tables are checked against each other automatically.

## Table 6 and Fig. 3 — training curves

Read `artifacts/checkpoints/<run>/stage{1,2,3}_*_log.json`, or convert with
`EpochLog.to_csv`.

## Table 7 — ablation

```bash
for V in A B C D E F G H I J K L; do
  for S in 0 1 2 3 4; do
    python scripts/run_experiment.py --variant $V --seed $S --dataset isic2019
  done
done
python scripts/cls_metrics.py \
  --predictions artifacts/predictions/B_isic2019_seed{0,1,2,3,4}/classification/predictions.csv \
  --compare-with artifacts/predictions/A_isic2019_seed0/classification/predictions.csv \
  --aggregate
```
`--compare-with` gives the `p vs (A)` column. Table 7 reports the
median-performing seed as the point estimate with the across-seed standard
deviation beside it; `--aggregate` prints both.

## Table 9 — segmentation

```bash
python scripts/seg_metrics.py \
  --predictions artifacts/predictions/A_isic2019_seed{0,1,2,3,4}/segmentation \
  --ground-truth data/isic2018/masks --aggregate \
  --out artifacts/tables/table9_A.json
```
Table 9 reports the five-seed mean ± s.d., which is what `--aggregate` prints.
The checkpoint stage of each run is read from its manifest and echoed; mixing
stages in one aggregate raises a warning, because a Table 9 row must come from
a single stage. The "w/o joint fine-tuning" row comes from variant `G`, whose
predictions are written from the Stage-1 checkpoint automatically.

## Table 10 — baselines

```bash
python scripts/count_macs.py --baselines --out artifacts/tables/table10.json
```
for the capacity columns — but read `docs/KNOWN_DISCREPANCIES.md` first: the
reimplementations here are not necessarily the configurations you trained, and
the published GMAC column disagrees with any consistent counting convention.

## Significance tests

`annee/stats.py` holds McNemar, DeLong and the bootstrap; `cls_metrics.py`
drives the first two. All three operate on saved predictions, so every p-value
and interval in the paper is recomputable without a GPU.
