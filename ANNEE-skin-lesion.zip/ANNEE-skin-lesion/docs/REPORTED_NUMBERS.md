# Which script produces which number in the manuscript

Numbers in the paper that come from the data must come from a command here,
not from a previous draft. The second column is the sentence or cell they
belong to.

## From `scripts/make_splits.py`

| Printed as | Belongs to |
|---|---|
| `ISIC 2018 Task 1 split: a train / b validation / c test` | Section 3.11.2, "partitioned 80/10/10 into 2,075 training, 259 validation and 260 test images" |
| `matched segmentation lesions` (per archive) | Section 3.11.1, "1,912 have at least one counterpart in ISIC 2019 and 1,468 in HAM10000" |
| `rule (i) forced into train (lesions)` | Section 3.11.1, "1,531 of the matched lesions in ISIC 2019 and 1,174 in HAM10000" |
| `rule (ii) excluded (lesions)` / `(images)` | Section 3.11.1, "381 … comprising 412 images, and 294 … comprising 318 images" |
| `pool after exclusion` | Section 3.11.1, "from 25,331 to 24,919 … from 10,015 to 9,697"; Table 3 Images column |
| `Table 3 row: … train+val … test …` | Table 3, Train + val. and Test columns |

## From `scripts/verify_leakage.py`

The claim in Section 3.11.1 that "for each of the five seeds, the intersection
… is empty, and the same holds at image level" is this script exiting zero on
all five seeds. Keep its output with the release.

## From `scripts/count_macs.py`

Every cell of Table 2, the GFLOPs figure and the three percentages in
Section 3.9; the capacity columns of Table 10.

## From `scripts/cls_metrics.py`

Tables 4 and 5 in full; the accuracy, macro F1 and macro AUC of Table 7; the
bootstrap intervals quoted in Section 4; the `p vs (A)` column.

## From `scripts/seg_metrics.py`

Every cell of Table 9, and the Dice/IoU/HD95 columns of Table 10(a).

## From the training logs

The convergence claim "α_norm ≈ 0.31 and β_norm ≈ 0.69" (Sections 3.5,
3.11.1): read the final row of `stage1_log.json`, fields `alpha_norm` and
`beta_norm`. The raw coefficients and `s_e`, `s_l` are in the same row.

Table 6 and Fig. 3 come from the `train_accuracy` / `val_accuracy` columns of
`stage2_*_log.json` and `stage3_*_log.json`.
