# Manuscript ↔ code map

Where each claim in the paper lives in this repository, and which test pins
it. The four sections below follow Reviewer 2's four remaining requests; the
last section maps the rest of the paper.

---

## Comment 1 — model checkpoints and data usage behind the segmentation results

> *"Please specify which training-stage checkpoint was evaluated for each of
> these entries ... identify the classification dataset used for that
> fine-tuning ... confirm, using the actual split assignments, that the ISIC
> 2018 segmentation test images and other acquisitions of the same lesions
> were not used in any training stage contributing to the evaluated
> checkpoint."*

| Claim | Code | Test |
|---|---|---|
| Every Table 9 row except "w/o joint fine-tuning" is a Stage-3 checkpoint | `annee/variants.py:checkpoint_stage`, `STAGE1_ONLY` | — |
| The checkpoint is loaded accordingly and recorded | `scripts/run_experiment.py`, `annee/predict.py:predict_segmentation` (`checkpoint_stage`, `finetuned_on` in `manifest.json`) | `scripts/smoke_test.py` artefact check |
| Stage 3 is run per archive; Table 9 uses the ISIC 2019 one | `annee/train.py:train_stage3` (file names carry the archive) | — |
| Stage 3 updates decoder + gate, encoder frozen | `annee/train.py:freeze_encoder` | — |
| Rule (i): Stage-1 training lesions forced into classification train | `annee/splits.py:build_splits` | `test_rule_i_forces_stage1_training_lesions_into_train` |
| Rule (ii): ISIC 2018 val/test lesions excluded from the archives | `annee/splits.py:build_splits` | `test_rule_ii_excludes_heldout_segmentation_lesions` |
| The empty-intersection check, on realised assignments | `annee/splits.py:verify_leakage`, `scripts/verify_leakage.py` | `test_verify_leakage_passes`, `test_verify_leakage_detects_an_injected_violation` |
| Grouping never splits a lesion | `annee/splits.py:stratified_group_split` | `test_lesions_are_never_split_across_subsets` |

The second of those tests matters as much as the first: a checker that cannot
fail proves nothing, so it is given a deliberately poisoned split and must
raise.

---

## Comment 2 — a consistent training objective

> *"Please provide one implementation-consistent formulation for each training
> stage ... Clarify whether the reported values α≈0.31 and β≈0.69 are the
> actual coefficients ... The loss reduction and any normalization or
> constraints on these weights should be stated explicitly."*

| Equation | Code | Test |
|---|---|---|
| (13) `L_edge`, mean over Ω | `annee/losses.py:edge_preservation_loss` | `test_edge_loss_is_mean_not_sum` |
| (14) `L_lesion` = Dice + BCE + boundary | `annee/losses.py:lesion_loss` | `test_lesion_loss_contains_region_and_boundary_terms` |
| (15a) Stage 1 | `UncertaintyWeights.stage1_objective` | `test_stage1_objective_matches_equation_15a` |
| (15b) Stage 2 | `losses.stage2_objective` | `test_stage2_objective_is_classification_loss_alone` |
| (15c) Stage 3, no `L_lesion` | `UncertaintyWeights.stage3_objective` | `test_stage3_objective_matches_equation_15c_and_drops_lesion_term` |
| (23) class-weighted cross-entropy | `losses.classification_loss` + `inverse_frequency_weights` | `test_classification_loss_applies_the_class_weights` |
| `s_e`, `s_l` initialised at zero, shares start at 0.5 | `config.S_INIT`, `UncertaintyWeights.__init__` | `test_log_variances_start_at_zero_and_shares_at_one_half` |
| **0.31 / 0.69 are normalised shares, not raw coefficients** | `UncertaintyWeights.normalised_shares` vs `.alpha_raw` / `.beta_raw` | `test_raw_coefficients_are_not_the_reported_shares` |
| No constraint, clipping or normalisation during optimisation | `UncertaintyWeights` (plain `tf.Variable`) | `test_no_constraint_is_applied_to_the_log_variances` |
| Fixed-weight variants (J)–(L) drop the `s` terms | `UncertaintyWeights(fixed=...)` | `test_fixed_weight_variants_drop_the_log_variance_terms` |
| Training path uses soft mask, gradients flow | `postprocess.classifier_input_soft` | `test_training_path_never_thresholds` |
| `c_soft → c` for binary maps | `postprocess.soft_confidence` | `test_soft_confidence_approaches_hard_confidence_for_binary_maps` |

The per-epoch trajectory of `s_e`, `s_l`, the raw coefficients and the
normalised shares is written to the training log by `annee/train.py:_weight_trace`,
so the convergence claim is checkable against the log rather than asserted.

Two further corrections made in the same revision:

| Claim | Code |
|---|---|
| Eqs. (16)–(18) act on the binarised **region** map `M_bin = [R̂ > τ]` | `annee/postprocess.py:inference_mask` |
| Eq. (23) carries the inverse-frequency weights `w_k` | `annee/losses.py:classification_loss` |

---

## Comment 3 — reproducibility and the placeholders

> *"Please replace these placeholders with the actual counts and a working
> repository or reviewer-access link ... For segmentation, the prediction
> outputs required to recompute the segmentation metrics should also be
> identified and provided."*

| Promised in Section 3.12 | Produced by |
|---|---|
| implementation | this repository |
| pinned environment | `requirements.txt`, `environment/` |
| split index files, all five seeds | `scripts/make_splits.py` → `artifacts/splits/seed*/` |
| lesion identifier lists for both rules | same, `leakage_counts.json` + `split_index.json` |
| per-image classification predictions with full probability vectors | `annee/predict.py:predict_classification` |
| per-image segmentation masks and probability maps | `annee/predict.py:predict_segmentation` |
| Stage-1 and Stage-3 checkpoints | `annee/train.py` |
| per-epoch logs, incl. `s_e`, `s_l`, the two shares | `annee/train.py:EpochLog` |
| metric, CI and significance scripts | `scripts/seg_metrics.py`, `scripts/cls_metrics.py`, `annee/stats.py` |
| the ⟨n⟩ counts | `scripts/make_splits.py` prints them; see `docs/REPORTED_NUMBERS.md` |

---

## Comment 4 — reporting consistency

| Claim | Code | Test |
|---|---|---|
| One MAC convention for every model | `annee/macs.py`, used by `scripts/count_macs.py` for ANNEE *and* baselines | `tests/test_architecture.py` |
| Table 2 reproduces exactly | `scripts/count_macs.py` | `test_segmentation_parameter_count`, `test_segmentation_macs`, … |
| Classifier alone vs complete pipeline | `scripts/count_macs.py:table10_capacity` | — |
| Grouped convolutions counted correctly | `annee/macs.py:_layer_macs` (`groups`) | — |
| Dense applied to a 4-D tensor is a 1×1 convolution | `annee/macs.py:_layer_macs` | — |
| McNemar for the `p vs (A)` column | `annee/stats.py:mcnemar` | `test_mcnemar_detects_a_consistent_difference` |
| DeLong for AUC comparisons | `annee/stats.py:delong` | `test_delong_separates_a_strong_from_a_weak_score` |
| Bootstrap, 1,000 resamples | `annee/stats.py:bootstrap_ci` | `test_bootstrap_interval_brackets_the_estimate` |

See `docs/KNOWN_DISCREPANCIES.md`: the counter does **not** reproduce the
baseline GMAC column currently printed in Table 10, and the evidence says the
table is what needs changing.

---

## The rest of the paper

| Section | Code |
|---|---|
| 3.2.2 resizing | `preprocessing.np_resize_image` (bilinear + anti-aliasing), `np_resize_mask` (nearest) |
| 3.2.3 normalisation, Eq. (3) | `preprocessing.np_minmax` |
| 3.2.4 smoothing, Eqs. (5)–(6) | `preprocessing.np_gaussian`, `tf_gaussian` |
| 3.2.5 Sobel, Eq. (7) | `preprocessing.np_sobel_magnitude`, BT.601 luma in `np_luma` |
| 3.2.6 fusion | `models.attention_gate` |
| 3.2.7 two heads, `E_true` | `models.build_segmentation_network`, `preprocessing.np_boundary_target` |
| 3.5 adaptive mechanisms | `models.attention_gate`, `losses.UncertaintyWeights` |
| 3.6 coupling, both paths | `postprocess.classifier_input_soft` / `classifier_input_hard` |
| 3.7 post-processing, Eqs. (16)–(18) | `postprocess.inference_mask` |
| 3.9 complexity | `macs.count_model`, `macs.classical_stage_macs` |
| 3.11 architecture and schedule | `config.py`, `models.py`, `train.py` |
| 3.11.1 three stages | `train.py`, `splits.py` |
| 3.11.2 ISIC 2018 protocol | `splits.build_splits` (segmentation block) |
| 3.12 reproducibility | this repository |
| 4 ablations (A)–(L) | `variants.VARIANTS` |
| 4.2 baselines | `baselines.py` |
| Algorithm 1(a) TRAIN | `train.py` |
| Algorithm 1(b) INFER | `predict.py` + `postprocess.py` |
