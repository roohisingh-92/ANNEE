# Datasets

None of the three archives are redistributed here; each carries its own terms.

| Archive | Used for | Source |
|---|---|---|
| ISIC 2018 Task 1 (Lesion Boundary Segmentation), 2,594 images + expert masks | Stage 1, every segmentation metric | https://challenge.isic-archive.com/data/ |
| ISIC 2019, 25,331 images, 8 classes | Stages 2–3, classification metrics | https://challenge.isic-archive.com/data/ |
| HAM10000, 10,015 images, 7 classes | Stages 2–3, classification metrics | https://www.kaggle.com/datasets/kmader/skin-cancer-mnist-ham10000 |

## Expected layout

```
data/
  isic2018/metadata.csv        image_id,lesion_id[,isic_id]
  isic2018/images/<image_id>.jpg
  isic2018/masks/<image_id>_segmentation.png
  isic2019/metadata.csv        image_id,lesion_id,label[,isic_id]
  isic2019/images/<image_id>.jpg
  ham10000/metadata.csv        image_id,lesion_id,label[,isic_id]
  ham10000/images/<image_id>.jpg
```

`label` must be one of the class names declared in `annee/config.py`
(`ISIC2019_CLASSES`, `HAM10000_CLASSES`).

`lesion_id` is what makes the splits lesion-grouped. HAM10000 ships it
directly. For ISIC 2019, derive it from the official metadata's duplicate and
near-duplicate annotations; where no grouping information exists, fall back to
the image id, which makes grouping a no-op for that image.

`isic_id` is the primary key for cross-dataset matching in
`annee/splits.py:match_lesions`. Supply it wherever the archive provides it;
matching falls back to `lesion_id` when it is absent.

## Why `lesion_id` matters

Both leakage-control rules of Section 3.11.1 operate on lesions, not images.
If `lesion_id` is wrong or missing, the splits are still produced and
`verify_leakage.py` still passes — but it passes vacuously, because there is
nothing to match. Check the matched-lesion counts printed by
`scripts/make_splits.py` against what you expect before trusting them.
