# artifacts/checkpoints

Populated by the commands in `docs/REPRODUCING.md`. Empty in a fresh clone.
See `RELEASE_CHECKLIST.md` for which contents must be committed before the
Section 3.12 availability statement is accurate.
